GTA map styles for QGIS - Isle of Man
by Alikhan Beisenbayev (@tulparmaps)

Three looks: GTA VI day, GTA VI night, GTA V.

OPEN A READY MAP
Open qgis/projects/<style>_isle_of_man.qgz in QGIS 4.2 or newer (made in 4.2.3).
The layers come from data/isle_of_man.gpkg and data/relief/. Keep the folders as they are.

USE A STYLE ON YOUR OWN DATA
Each .qml in qgis/<style>/ matches a layer in a Geofabrik GeoPackage
(landuse, water, roads, places, pois ...). Layer Properties > Style > Load Style.
Layer order, top to bottom:
  pois, pois_a, transport, transport_a   (icons, drawn as labels)
  places                                 (names, labels only)
  relief_light, relief_shadow            (shade.tif, screen and multiply blend)
  transit                                (GTA VI only: a 2nd copy of railways)
  roads, railways, buildings, ferry, waterways, water, natural_a, landuse
  coast, sea                             (sea.tif)
Set Project > Properties > General > Background colour to the land colour.
Icons sit in the Labels tab, not Symbology. <style>_library.xml imports into the Style Manager.

FONTS (not included, install them first)
  GTA VI: D-DIN Condensed, Futura PT Cond
  GTA V:  Century Gothic

DATA
Map data (c) OpenStreetMap contributors, ODbL. Relief from Copernicus DEM GLO-30.
Fan homage, no Rockstar assets.
