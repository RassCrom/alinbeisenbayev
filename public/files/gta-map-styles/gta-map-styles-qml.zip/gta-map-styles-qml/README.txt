GTA map styles for QGIS - Isle of Man
by Alikhan Beisenbayev (@tulparmaps)

Three looks: GTA VI day, GTA VI night, GTA V.

USE A STYLE ON YOUR OWN DATA
Made in QGIS 4.2.3; use 4.2 or newer.
Each .qml in qgis/<style>/ matches a layer in a Geofabrik GeoPackage
(landuse, water, roads, places, pois ...). Layer Properties > Style > Load Style.
Layer order, top to bottom:
  pois, pois_a, transport, transport_a   (icons, drawn as labels)
  places                                 (names, labels only)
  relief_light, relief_shadow            (shade.tif, screen and multiply blend)
  transit                                (GTA VI only: a 2nd copy of railways)
  roads, railways, buildings, ferry, waterways, water, natural_a, landuse
  coast, sea                             (sea.tif)
Set Project > Properties > General > Background colour to the land colour.
Icons sit in the Labels tab, not Symbology. <style>_library.xml imports into the Style Manager.

FONTS (not included, install them first)
  GTA VI: D-DIN Condensed, Futura PT Cond
  GTA V:  Century Gothic

DATA
Map data (c) OpenStreetMap contributors, ODbL. Relief from Copernicus DEM GLO-30.
Fan homage, no Rockstar assets.
