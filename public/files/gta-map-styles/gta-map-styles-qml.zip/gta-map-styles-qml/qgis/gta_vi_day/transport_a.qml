<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis autoRefreshMode="Disabled" autoRefreshTime="0" hasScaleBasedVisibilityFlag="0" labelsEnabled="1" layerType="Vector" maxScale="0" minScale="100000000" readOnly="0" simplifyAlgorithm="0" simplifyDrawingHints="1" simplifyDrawingTol="1" simplifyLocal="1" simplifyMaxScale="1" styleCategories="AllStyleCategories" symbologyReferenceScale="-1" version="4.2.3-Belém do Pará">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal accumulate="0" durationField="" durationUnit="min" enabled="0" endExpression="" endField="" fixedDuration="0" limitMode="0" mode="0" startExpression="" startField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation binding="Centroid" clamping="Terrain" customToleranceEnabled="1" extrusion="0" extrusionEnabled="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" symbology="Line" type="IndividualFeatures" zoffset="0" zscale="1">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="line">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{63c20247-4240-407a-982e-abb9221110b2}" locked="0" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="125,139,143,255,rgb:0.4901961,0.5450981,0.5607843,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{d47eb7fa-a2f9-44b1-be17-af03a3c4a7da}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="125,139,143,255,rgb:0.4901961,0.5450981,0.5607843,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="89,99,102,255,rgb:0.3501335,0.3893492,0.4005493,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" id="{20ddff49-03b0-4a39-978a-c66fb9e4003c}" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="125,139,143,255,rgb:0.4901961,0.5450981,0.5607843,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="89,99,102,255,rgb:0.3501335,0.3893492,0.4005493,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" forceraster="0" referencescale="-1" symbollevels="0" type="nullSymbol">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <labeling type="rule-based">
    <rules key="{1a99af35-54a4-4b8d-ac7b-d577ef3bb1ae}">
      <rule description="station" filter="&quot;fclass&quot; IN ('railway_station')" key="{ec3be2d0-fc18-4cf5-90e8-6979f0a7d150}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.980208333333334" shapeSizeY="10.980208333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="1"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFMAAABTCAYAAADjsjsAAAAHaUlEQVR4nO2cjW7bNhDHRdrdqyTZgG3pnqvrs3R7rnTdgC71qywJNcgTg9Ppfx+kKNmZfYBgiZIo8uc7HknxFLr1JbBfnm6dk6RXjqVzPL2phI3yDsKvlaYJgqelabCbyH6FPAP7RWlBAWxB9QDzwurPVTMDyJNDK9n3wuwr92le/bnAlDQwsH2aFpVzHKgkCBJNS8o5vk/zPBlMy3yDskUHTE0zNZgJpHmh9qeAKYEMBriowERguUgAEcxUAJjnvYkD0rQxChDpL0rTgOZnoLbSgpjIfhCgJpA/fU4xmJbaGBk4dIzSl2omBZfAxtM1beXPaa6ZFshogNsJ6ZqGejVTgzhsL0QD85aP8zX8D8vPlLS2GqYEkreFUYC3U9ImMFNKD84ydTHGXwSYL2w/grQMkgLMeVQBDQ1Aalq4IxuCuiuB54SboaHfvHHgmvm7TT40BLkDANEWU0p/dCtLjPEeQEQbAlsF1APTAilB3PO0LSAKUDnAZwdUCWgVzBqQe7Z/PE4pfelOLDHGnwlICvO5FVAJJvLYEkgIsBv3U0qfvRXu+767+/jo7mE8frp7DsHfu4sxvmcwEVgLqGjuqCRW1weB3DOYGeRDa4BLwY5OKkPkYCWgqD96LL4HJhrRSGadQb4jEE2zvv317zWm/47y7bfvByAes88wnwRNpVBR10mFKZl3VJzMnoB8ZzmZNSGWQh2d0xMBymG+GBraUaB5KoyKNTSMyKQ7A+RgzluCHGR43vBcScbyvloUszTPKG0i0fDekuPhmrk3QIYW7WKNDM8dni+dH8vNQdKBhgZyApWPfy3znmhi/ldTSn9Khd1aG2vNPsb4EzF3avK8DRUdEp/xpvvamJtr59mDdJRnNsgQTF3UTt5mok66Zd4PbwGkVa6xHpa5U6CDTJqPfDILJ696c6lDfnumIB1APxvaifhkCZaZ08aXg4R9yV5p7M9JpHKO9UJATSeEzFwb8dAHoAJ2dx8f4blzk6GcSrdJmjpEGgrNHKkwnNSQukF3J+r+1IpU3rF+CKTEaJDjYBYNGdEIZ9i+kzrntwvbycPvPyy5vbv58LVpl4mMjv4B3SU+Ojp2j3ibaTmgVSZ2DwtBtsqDylhPq2s00U5k5nlfehXRtdTKQ0MItXkp5UftpcgMweFmz9vNZnJorE0r5KkNKWfs8j8iufuJhqIOujaRsEV71wriUA8+HzrUdxxmSl6cHvfeTvusG/BWPbgkSj0QB1en3XJClyjR4Xxgp72zbmht4uckQn3cPKT5zFkmqL38v5i4Vp+x3qJp02PUHkoN7CVLELhMzmvtoHTjJUpgPKB4XltcxamhkgPix5cONQhcJmI5kE0gHlYYCa0kKg+r77hp3+fmw1f3aKjk2obSl8LkN6grv1rJDQFjQSq5tpEgBr0GE6302kQzbwAQCVLJtSsIWs2hruigN85uuFDpPYtdI4C1uYYegAOSnFLJtVtpJJ9pFy94vfC/pXizZXytSnsgQCw4JdeWCKoPCUJAijU5Rl0jFBcDtbNkoalHSsCsoY1Cfdw8ouMGGhJyiZK8sZi5zcwigRTbzSWmfrOCF67NU6kH4gBNHmkmP35d+YXazdamvkSW/DmoHmN9rYWus1VwVFAkLI3suiR5UQIFZs0efSUhLUJ4RxchpJT+avW698CcSI1mtchDWrcZY/yRLUJ4UhYhJI8DmoTDjSsdFsthpb5hq3xJhJu2wBWaOXdCVnRsVYTDGu3dUiemlFuLr8xgs8y8uaWZr6EcknY+Oj17C9PU7vdqp1ReEiKIAqwkjz4ZAXWKeaPIWOgRHz/dmU5q7YkJT/5DOZWeiCdQddZd5G0m3efefBIbMwYlzSSE0JdUuBXY0vykcpIYS+hklO4RfOfD1xZJywuP21tciv1N9t7vmefWlhHOzB6ZeaeYOg3YPG6oI9/CIZ0AJI+ptCLUulIzR54dxW53bwGoUR4rzE8LRp2Yed7Px7EgsCqH+n0xItROttZ9dDZiWz62kyiGUguomgWkel5boCElMvd7qbBDRVrOfVaETmsg7x3mbTqfY14gfw0kBcpjtp8MoJub/fA8bSKGRfVyoNaHUGZ/EHoSMnc6bkcmv7vGm8swKdTZCuLrlxA66M0lG0BA0fr24ff6jY5RtJldtEBJArq7fj3GXktUA3R3/a6RDLNzAI3XL275VrmVAI0KWJ5+cd+C8wINClAEEQV4rvmVQikNDRWrQJbA1IBymMHQVrTxPwatGecz257BhQaP3yONu10gBymZJutJpXjlOlKgqEyWSBAlkOjPtiZkJKi9Y0RTDVIqrPcetK47Kn1TpL2SRpZqJtJQBBgBnE1Y1ICkQGrEMvugtK0WxBrN1KBqWrgYIgdSK5qWhgLA6D6pfGjGRoLpgdcEpFTYJXkEB9RBpJhNfq8mGswOmK8Fke+fBCbPK7C0ULkvlQ+1nTX7NK9FELXCtsozKGnIlLX7qGgwvObbFGKWNd4g9oXXeSFqz/EAa2bOW2pmJzyDP0uDVwqTH0vnVoGY5V9Xa+1ejZDCfgAAAABJRU5ErkJggg=="/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.9802"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="9" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{c6825298-6c39-4dea-8c1b-6b5477b39a71}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="hospital" filter="&quot;fclass&quot; IN ('hospital')" key="{bc98b97d-4c27-4192-8ec8-9874a220fbd8}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.980208333333334" shapeSizeY="10.980208333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="1"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFMAAABTCAYAAADjsjsAAAAG5ElEQVR4nO2cbXLjNgyGRdrZq2zS/mh3e652z9L2XNluf7RJr9IkVEcZ0YWg9wUgWfI3ZjSmKIsiHwMkSBNKzfqS1KfO964xaY1zdk3nLyrpQGUn8unlWYLgWXkW7EVku0KZSX2ivGQA9qBGgEVhtaeqmQmUqaFNSUdhtjPTsqz2VGAyDUwqLfOycU0DZYIgybxiXNNpWebRYHrmm4wjB2BammnBLCAvCrU9BkwGMjngsgETgdXCACKYZQJgXfZBBiBLGzOBKD9RngW0PgP1lR7EItKJQC2gfPmcyWCW1MaswKFzlL+vZkpwBRw639JW/ZzFNdMDmR1wG5JvaWhUMy2I3fEmNLAe9bx+R/9g9ZlMa2fDZCB1X5gJvI2RN4BZSnkM1qnJOf9EYL6pdAZ5FaQEWMuYBTQtANLSwo04ENTNFHhBuBUa+qyHBm6Zf9jk04IgNwAgOnIp5Y9mZck5fwIQ0YHAzgIagemBZBC3Ou8QEAlUDfA1AJUBnQVzDsitSr+fl1K+NUeWnPOPAqSE+boUUAYTjdgMJATY9OlSytdog9u2bR6+PIU9jKdfH15Tint3OefPCiYC6wGl5o5q4rk+CORWwawgH5cGuC/YfpCqEDVYBhT5o+/Vj8BEMxpm1hXknYDomvX9L3+vsfz3Ls+/fdcBiZh9hflCNFVCRa6TCZOZdzYGma0AeecNMmtCnAq1H5xeBFAN883R0EYCrUthUrypYUYm3TggO3M+JMhOuud1z2XS13dnUcrSIrO0gWRn9GYDj9bMrQMyLdEvzpHuud3z2fW+3hqknGhYIAdQ9fzXM++BJtZftZTyJ6vsobVxrtnnnH8Q5i5NXvehdEDSK94ybc25tXaePMhAfUaTDGLqVDt1n4mcdM+8H88BpFevvh2euUugnQy6j3qxiiZvjubMIb8/UZABoF8d7UR8qiTPzGXnq0FCX7I1OvtTElbPvl0IqDsIITO3ZjzyAaiCzcOXJ3jt1KSrp+E2saVDpKE7qdAax5e8E8cHNnrfL2Te//z+vfudjz//teoI34/u/4rRXTv1eh10MJpXYQu+8hc6u36SiVFvpJFaO6sMzBx1rNA1Osaa5DGkb6fnGg3MXRLWnerFa+Ue2gmZITjZmUpek2yMKeWIHTJzfS5NfOSgWwsJ5ySoHX17rVGcmrm+qLUT+mXHWsBYWox2IA4hp90bhK5RcmDwgU57491wiSbutCfMg61njgpB/eWlmLjVnr7d1LTl+db5Av0V1prZLF3WQjMlOh+X51Y/yG68RkmKB5TI3xY3CWooG4D0+bVDTYTLQDx359ohTuLhwbws32d/aafC1DeYO7+uRFrChcJEO72uHaIWtJvD3NEhbxzdcKXSRja7bgGs1TT0Y9CBPuTfFktoZD1nZq4LaPuteKNtfM0FyRNojwhCQIrlmjmKi4HaOWWj6TkIaU+YRw7cIENCrlFKNBYzW6ZN9nRfpKk/8XYgDtDkkWbq891/w6jfvBRTT6AdfXu9ja6jXXBSUCSsjOy6JnkzAgVG3Z40c02cxR/O2kN+ymLUn0WyQWaRAWhQUL8P/OIl/x/hZm1whWauByEvOvZitPN5ulZq7Wxqmv0LKTduybCUD3UDF9om0y4U03MoYbFDIgrjpd+8pcNb4JZsPQAx80aRsSNJKXUVPItBqqun4YlEAlVH7qLuM2Vaj+aD2Jg+KGkkKaVF5vFrC6uniLHUQJGv2cxx2gsB2sUinl3/+cz3ZH6eEFBFnfZdhvi0QO7COpAjf8pADZA6ptID2kw1c+ZvarDNOQB16uOF+VnBqLvRHP0Dp7cSWoFVNdTvmxOhtjnyYEP78r6fRDGUVkDVKCA18rcFmlIic//EKts15FgLIr37Y4H8FDBvd/B5LwuUb4GUQHXM9osD9OBm3z3PWohRUb0aKDJx6hZ1gp6EzL2a/C3evInHm8s8b3bUfd7ehCCE2QACiva3S6Cb2zs6uKANSgzo5vb2GH8v0Rygm9t7jXxzt4Dm2xu3YrvcpgDNBth87e+CiwJNBlAEUafXfkshy0NTxVkgp8C0gGqYydFWdOgfBu0Zt1a32OTCgqfvYfPuEMhOpqyKt6JRunGNqFA2FksYRAYS/djeggyD2gZmNLNBsspG70H7urPhmyLtZRo5VTORhiLACCCa0UwGKYHMEc/sk9G3ehDnaKYF1dLCvSFqIHPF0tI0ATC6j9UPrdgwmBF4i4Bkld2njBSA2gmL2dT3WmLBbID5ehB1+igwdVlJ5aWZaVY/1HfOScuy9oJoVXapMpORh0zZuk+KBSNqvotCrLLGhoF24veiEK3nRIAtZs6H1MyGPEM/y4I3FaY+Z9dWgVjlP/rup+cVxsdiAAAAAElFTkSuQmCC"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.9802"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="8" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{de29e225-b278-4faf-ac1c-be2752e0dd95}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="marina" filter="&quot;fclass&quot; IN ('ferry_terminal', 'slipway', 'marina')" key="{3de8b062-0d62-4ffb-b84c-7be9080fcbb8}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.980208333333334" shapeSizeY="10.980208333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="1"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFMAAABTCAYAAADjsjsAAAAHS0lEQVR4nO2cC3LbNhCGCVDuDeTcoqmTY7Vuz9K6PZbTpLdIdYPYBjtUCc1y+e+DIKhHpJ3hiARFEPi0CyyAhUKzvgT2ydOte5J0yrV0j6dXlXCkvIPwaaVpguBpaRrsKrJZIc/APlFaUABbUD3AvLC6c9XMAPLk0Oace2F2hec0r+5cYEoaGNg5TYvKPQ5UEgSJpiXlHj+neZ4MpmW+QTmiA6ammRrMBNK8ULtTwJRABgNcVGAisFwkgAhmmgGY532UDkjTxihApJ8oTQOa34HaSgtiIudBgJpA/vQ9s8HU1MbIwKFrlL5UMym4BA6ermkrf091zbRARgNcK6RrGurVTA1if7wRDcxHvs7f4T9YfqektcUwJZC8LYwCvFZJG8FMKT07y9TEGD8KMN/YeQRpGSQFmPMoAhoqgNS0sCUHgtrOgeeEm6Ghz3xw4Jr5u00+VATZAoDoiCmlv5uVJcb4ACCiA4EtAuqBaYGUIG542jEgClA5wFcHVAloEcwSkBt2vr9OKX1uTiwxxp8ISArztRZQCSbqsSWQEGAznKeUPnkr3HVd8+6v39wexteff38Nwe/dxRg/MJgIrAVUNHdUEsv1QSA3DGYG+Vwb4FKwQyeVIXKwElDkj+6L74GJRjSSWWeQdwSiadb3f/66xvTfXv795Y8eiMfsM8wXQVMpVOQ6qTAl845KJ7MhIO+sTmZNiHOhDp3TCwHKYb4ZGtpQoHkqjIo1NIzIpBsDZG/OxwTZS/++/r2SDOU9WBSzNM8obSTR6L2ljodr5sYAGWq0iyXSv7d/v3R/KDcHSQcaGsgRVD7+tcx7pIn5V00pfZEKe2xtLDX7GON7Yu7U5HkbKnZIfMabnmtjbq6dZw/SUZ7JIEMwdVE7eZuJnHTLvJ8vAaRVrqEelrlToL2Mmo98Mwsnr/bmkkN+f6YgHUA/GdqJ+GQJlpnTxpeDhL5kpzT25yRSOYd6IaBmJ2RpIXfIf8gdD+q9u0qjGSq7x6fD+fbpsWbW4qiJ+J/98Q049rAzomaOVBhOakhu0LsVQaLrpSKVd6gfmtCWGPWy/1nQkBGNcO6yZiKY95XbyQyOaiNKW8tlItr5DbhLfHR00MxGIT5xjU4xJ3kKGeppuUYj7URmns+lpYiL670tUcrPzZxCnTBDmXCz5+3mUWT79Lg3a95O1jZxQ1qyIIeaxNGqJjJzfk1NfOKgaxMJS4WDWxMkqsdQX8nMG83M+U2undAvO9UERm1R6oE4uJx2qxO6RomOzmcPFf0a6gNrmfjO4UNK36ll/n19gBPv5iHNZ04yQe3l92LiWn2GeoumTa9Reyg2sFcsQeAyuq9plvTgKrIVTHXNsfkM4SCheJYtbuLUUGlBjV9fO9QgcBmJ5e5cO8RZPCyY6w1vLlO6uTD5A2rk15VIJ3ARYaJIr2uHyAVFc6gRHfTByQNXKp0n2DUCWDcNnamRfKZd/MLhi/+H4k0WpJrvSL6C+pBNCKjpG12jERDaFwNNfU6g6TFGNUvXiIT6uHlExwN0S8hFyK7uKqYUWwRjjUTTFmK6F5v6lq04Lq08z6NEM5V6IA7Q5JFm8uvDYjtqN0tNfcsqXAq01hqREIzw0RHoerhGbWYiGot2flVfNMvi1a61J4mJaBsFJs0eXZKQghDuaBBCSumf2su9uwpt3BKQUtxmjPFHFoTwogQhpAwAqe3EzAdTf6gdiLAdQJRAXWuOk+xw0wJcR2aetbEx4ta5dn5ZMxhh54BaC6Kile8FrUSBW3uTP/souDVljSg4KpJ5o52xEwkh9AWs2kmtJX05FU/Es1F14i5y14ie8958tDdm2JQ0kRDCRUyKSOUkeyxhJ6ON071OexKA9nsRi3aInVKUdvLDjA1VotN+SCCfGsjDtg7kyJ8zUAUk31NpAW3mmvnENRL2bjeXANQoj7XNT9uMenCN0ApcnLGxKm/1+2zsUDtaOKLQ2Yht+dBOoj2U2oaqyYZUz7IFGlIic3+QCttX5FRzn4P7o4F8cJi32fns8wL5ayApUL5n+8UAenSz79+nTcSwXb0cqPVHKJMfCL0JmTsdtyOTb2/7zWWYntFR/3n7JwQikg0goCi+nQJtb//RIQsKUJKAtrd/j7FjiUqAtrf/NbLNXQMab/+45YtymwM0KmB5+tX9F5wXaFCAIohog+ea/1IopaGhYhHIOTA1oBxmMLQVHfyHQTHj2uyWNLjQ4PFnpHG3C2Qvc2bFO1IpXrmGFCgqkyUSRAkk+rGtCRkJaucY0RSDlArrfQbFdUfFN0XaK2nkXM1EGooAI4CTCYsSkBRIiVhmH5S21YJYopkaVE0LF0PkQEpF09IwAzB6TiofmrGRYHrgVQEpFXZJHsEBtRdpzyZ/VhMNZgPM14LIz08Ck+cVWFooPJfKh9rOknOa1yKIWmFr5RmUNGTK2nNUNBhe860KMcsaAQPdzO95IWrv8QCrZs7H1MxGeAd/lwZvLkx+Ld1bBWKW/wC+VvN8GSR26gAAAABJRU5ErkJggg=="/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.9802"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="7" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{764eefb4-e362-4123-9990-83977acf0900}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="police" filter="&quot;fclass&quot; IN ('police')" key="{fc50c7d5-fd3b-45a5-b6af-24e40c438fe6}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.980208333333334" shapeSizeY="10.980208333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="1"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFMAAABTCAYAAADjsjsAAAAHU0lEQVR4nO2cgY7bNgyGJSW3V0mzAeuue66tz9Ltua5rB2xpXmV3Jw8+WAea/knKsmQnvRAwIsuxLH0hRUkW41178eyT51vXJOmUc+kaz68qfqWyvfBp5WmC4Gl5Guwqsm9QpmefKM8rgC2oOcByYXWXqpkelMmhzUnnwuwK07Ss7lJgShroWZrmBeUaByoJgkTzonKNp2mZm8G0zNcrR8iAqWmmBjOCvFyo3RYwJZDeABcUmAgsFwkgghlnAOZlr+KANG0MAkT6ifI0oOkZqK+0IEaS9gLUCMqnz5kNpqY2BgYOnaP8pZpJwUVw8HxNW/lzqmumBTIY4HZCvqahuZqpQeyPZ6KB6Ujn6Tv8B0vPlLS2GKYEkveFQYC3U/JGMGOMD5l1ciGEXwWYzywdQF4CSQGmMoqA+gogNS3ckQNB3c2Blwk3QUOf6eDANfPPNnlfEeQOAERHiDH+5RpLCOEeQEQHAlsENAemBVKCuOd5a0AUoHKATxlQJaBFMEtA7ln65TzG+MVtLCGEXwhICvOpFlAJJvLYEkgI0A3pGOPn3AZ3XeeOH0/ZI4zTp+OT9/mjuxDCBwYTgbWAiuaOamINfRDIPYOZQD7UBrgU7OCkEkQOVgKKxqMv1c+BiWY0klknkHcEomnW737/t8Xy34t8++PHHkiO2SeYj4KmUqho6KTClMw7KE5mT0DeWU6mJcS5UAfn9EiAcpjPhoY6CjQthVGxpoYBmbQzQPbmvCbIXvrn9c+VZKjvq0UxS8uZpY0kGN5bcjxcM/cGSF+jXyyR/rn986XrQ705SDrR0ECOoPL5r2XeI01Mv2qM8atU2bW1sdTsQwjviblTk+d9qOiQ+Io3TWtzbq6dFw8yoz6TSYZg6qJ28j4TDdIt8364BpBWvYZ2WOZOgfYy6j7SxSScvOrNpQH5uwsFmQH0s6GdiE8Sb5k57Xw5SDiW7JTOvlTOf/5Uu0ixnkO7EFDTCSEz12Y89AGogu748QSvXZr09VSGTdLSIdJQaOZIheGihjQMOjYY/iStbKGdUn2H9iGQEqOJmSdBHpwDvbp+UhKl3kgjuXYmGZm5RHwCdos1yS1kaKc1NBppJzLzlN5cK8/MtFuYeqF2QmYIDl8p4v3mW5KdMqWcsENmzs+piU8G6NpCwhKRtLCVdqJ2DO3VvLho5vwi1044LttqAaO2KO1AHLIG7ZYTeosSMpwPHLQ764YtTXwLU5/Do8/YCwsZaYnth/6IMf69xIufGwHIkcNv/yxapgsh/Oyc+2846BLdaDUe9YdiB7tWg2pKpeeK83F6rmmWdOPihp1X0NLKPx4HCSXntUV1OTTW0oblqxoqOSBUwFU0+NCmXMRgwsQa7jTRzFYNX6FfVnlY3rjN2KdyP7qic1N5hIwb1J1fteRQCGQlkIhBp8FEO72aQ7wyQbs51B0d9MbJDa3kXGjmK00G1N1vFCaHddPQmRqZziUz5wV0w1a8yTY+9x3JCbSHBCGgrs80cxQXA019zkbTaxChPdk8QsYNNCSkiZyVfq/31ukoub+CSHuL4F4j0bSFPd2rmfqBAWw5DFLagThAk98bHSzVytj3H/zVRQtTPyjQWi2WoHYM/aW10XWyC44KioSlkV1N5ZCpfSsN1rVAgUm3R19JeGOR+E5aJF7yuvc8aNgSOEvLkPZtkkXhR21ROMHNcUCjcLhhH3hVOSzUshZaSiLctA2uIzOn73/RpoO9oJ1fv5ctMt9krXwvaGXSTA565M0tzXwN5ZC083Rlg3ipviREEAVYSR59NANyinmjyFjoEU+fjs2dVA3p66mMRHICVSfDRd5n0jT35qPYmCEoaSLe++aLIjVEqieJsYRORpun5w7aowC0j0UsihC70H7yw4yAqsmgHZm5ywD5GtaBFkAuGagCksdUWkDdXDOfDI2E2G13DUCN+lhhflow6uvQCL2B41sJtcCqFOr3xYhQ223sbMS+fOgnUQylFlA1CUjNeW2BppTI3O+lyvYN2WrYNIROayDvM8zbdD4vZYHyNZAUKI/ZfjSArm72/fO0hRgW1cuBWn+EMvmB0JOQudN5OzL53S3eXIZJoU52EN/+CcFBby7ZgLQdm+9v7z9v/9ExiLayizYoSUB3t3+PsfcSlQDd3f7XSIbpMoCG2z9u5e1ymwM0KGB5/pv7L7hcoF4BiiDydOt/KZTy0FSxCOQcmBpQDtMb2ooO/sOgPePa6pY0udDg8XukeXcWyF7mvGboSKN44xypUFAWSySIEkj0Y1sLMhLULmNGUwxSqmzuPWhfd1DGpkh7JY2cq5lIQxFgBHCyYFECkgIpEcvsvdK3WhBLNFODqmnhYogcSKloWupnAEb3SfVDKzYSzBx4VUBKlV1Shs+A2osUs8nv1USD6YD5WhB5ehOYvCzP8nxhWqof6jtL0rSsRRC1ytYq0yt5yJS1+6hoMHLNtyrEJC12YHQzv5cLUXtODrBq5rymZjrhGfxZGry5MPm5dK0JxCT/AxHw3O1YyJfIAAAAAElFTkSuQmCC"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.9802"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="6" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{cf749aff-ad9b-4c19-80ee-809766f08120}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="sight" filter="&quot;fclass&quot; IN ('attraction', 'castle', 'museum', 'monument', 'theme_park', 'zoo', 'viewpoint')" key="{207a9c41-dd6a-4093-9685-6bd82554db1d}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.980208333333334" shapeSizeY="10.980208333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="1"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFMAAABTCAYAAADjsjsAAAAHTElEQVR4nO2cbXLbNhCGCUjpn0RnaHOBtm5O1uYcaU7mNO0F0pxB8Z/YBjvUEJ7V8n0XS4gfUqWd4QgETXw82gUWMFahmV+C+tT5pWdMWuOePdP5k0pYqOxAPkt5liB4Vp4FexLZzlBmUJ8oLxiAS1A9wLyw2nPVzADK1NDGpL0w28q0LKs9F5hMA4NKy7xoPNNAmSBIMi8Zz3RalrkazJL5BuOKDpiWZlowE8jzQm3XgMlAhgK4aMBEYLUwgAhmGgFYl73IBGRpYyQQ5SfKs4DmOtBYWYKYRDoQqAmUL+sZDWZKbYwKHLpH+adqpgSXwKXzLW3V9UyumSWQsQBuQ/ItDfVqpgWxu56FBuYr3+e/0V9YrpNpbTVMBlKPhZHA2xh5RzBTSvfONjUxxncE5rNKR5CXQUqAuYwqoGECkJYWbsSFoG7GwHPCzdDQZ740cMv83SYfJgS5AQDRFVNKfzUzS4zxDkBEFwJbBdQDswSSQdzqvCUgEqga4JMDKgNaBbMG5FalD/cppc/NyhJj/FWAlDCfpgLKYKIZm4GEAJs+nVL65O1w27bNw/u3bg/j9YcvTyH4vbsY428KJgJbAkrNHbWk5PogkFsFM4O8nxrgqWD7SSpD1GAZUOSPHprvgYlWNMysM8hXAmLRrL/98dMc238HefPnvx0Qj9lnmI9EUyVU5DqZMJl5R2OS2QqQr0qTzJwQx0LtJ6dHAVTDfC5oaCOB5q0wKaWlYUQm3RRAdua8JMhOuvq6epn07X2xKGVpnlXakcTC7M0mHq2Z2wLIMMW4WCNdvV397Hnfbg1SLjQskEdQ9fq3ZN5Hmpi/1ZTS36yxS2tjrdnHGH8R5i5NXo+hdELSO94yba25tXaePUhHewaLDGLqVDv1mImc9JJ5318CyFK7+n6UzF0C7eRo+MgPs2jy5mzOHPJvZwrSAfRTQTsRnyyhZOZy8NUgoS/ZGoP9OQlrZ98vBLQ4CSEzt1Y8sgLUwObh/Vv47Nyka6fhNrGtQ6Sh0MyRCsNNDeYGPazk/tQKa2/fPwSSMRqYeRY0g2ugFzdOMjHajTRSa2eWQzoXxIgPwM69J7n7+NX1d/vff5yzGQftjDH+7JiAMtQWmXlO/++18gTthMwQHL1TpMfNa5KNsaQcsNOukblrhBx0ayPhkgT1o++vNYsf3Xud9oEbcKkzOBOjH4gDdNo9E5DUzsUmmDOaqEqTT74OE5AW64WTTHw3Eci56iT9cfPoMrZkIyNvsf3QXSmlf06ZxXcVIJFW1X4hXg1F23S9i/S9v+QW3dFu/BbZPhtgl5K90fH8bGEtp+txeW+Ng+zFWWXv1KC5nXYlGiQUz78tFpP9SEALAy1qKBrzNMDFoUqR5rwCPIvBgEnJ3VnVvHdqXETj5ArmTqUEc7XlzY5MMGu4V14e0fGCefLrSqQlXChMdNLr2iFqQac5zBMd8sXBC1cqreewawSwVtHQnRoL2cSi8xcaQ02NzPfMzHUBbX8Ub3CMb772NwNwc8/cqD8iCAEp1tE98jNRXAzUzjEHTT3SadkYgFNrJemPm0d0vCBDQmaXnRPQgi4SO1sEzxpR0yZnumc39d3Hr6afOQdIox+IAzT5bWGAlVqZuvFD/+tialNfy0FH/ejHy9JB18EpOCkoElZGdlXJfr119Sl1W4ECg2FPmrkmzuIPq86QrwXUU6fRfhbJBplJM5cPoZn3pn53ykGE/YoaWhnhZh1whWauJ6FSdGy1dp6bVGil1s4GzeYlt+gllKP/1pqlnfiphbVXhAiiACs2ow/+O8nMG0XGwhnx9Ycv1ZPUktK10/BEPIGqA3dRO+0yrWfzo9iYPihpICEE6I+em7B2ihhLDRT5mk2N054I0C4W8eLGzzekfX1/vAFVA6cdmXnjAPkS1oE2QM4ZqAFSx1SWgDZjzZz5mxpscwlAC+0phflZwaiHNDt8EEcEVuVQv8+FCLXNypMNHcv7cRLFUFoBVYOAVM+/LdCSEpn7HWts15G13KY+dNoCeecw7+LkcygLlG+BlEB1zPZjAejiZt/VZ23EqKheDRSZOHWLOkE1IXPPJn+LN2/88eYyj53RlFBvv4QghNkAO44dDKCb2290cEEHlBjQze3XY8pniWqAbm6/a1Q2dwtovP3ilu+U2xig0QCr86/ut+C8QIMBFEFEAZ5z/kohy0NLxSqQY2BaQDXMUNBWFtSJwkNk3dbuFltcWPD0O2zd7QLZyZiAqFZ0SneuEQ2KxmYJg8hAoi+7tCHDoLaOFU01SNZY7zvoXHc0fFOkvUwjx2om0lAEGAFEK5rRICWQGimZfTDG1hLEGs20oFpaeDJEDaRWLC0NIwCj91j70I4Ng+mBNwlI1thTyggOqCyaGL1riQWzAeZbgqjTq8DUZQWVFyrTrH1o7KxJy7JOgmg1dqoyg5GHTNl6T4oFw2u+k0LMMkeseDvy77wQrXo8wCYz5yU1syF16LoseGNh6nv2bBaIWf4Dmpfv/0VXdvUAAAAASUVORK5CYII="/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.9802"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="5" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{1572842b-b1b8-45fe-b095-eb87a80abe83}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="bus" filter="&quot;fclass&quot; IN ('bus_station')" key="{520015e2-3423-41ba-8fc3-b6072568d379}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.980208333333334" shapeSizeY="10.980208333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="1"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFMAAABTCAYAAADjsjsAAAAHHUlEQVR4nO2ca3LkNBDHLXmyX5acAfYCQJaTwZ4DOFmWhQsAZ0j2C0lkylPWVLv974c08ry7yjW2PNbjN91qSVZP6NaXwD55unVPkkG5lu7x9KYSDpR3ED6tNE0QPC1Ng91ENivkGdgnSgsKYAuqB5gX1nCqmhlAnhxaybkX5lB5TvMaTgWmpIGBndO0qNzjQCVBkGhaUu7xc5rn0WBa5huUIzpgapqpwUwgzQt1OAZMCWQwwEUFJgLLRQKIYKYCwDzvgzggTRujAJF+ojQNaC4D9ZUWxETOgwA1gfxpOcVgWmpjZODQNUrfVzMpuAQOnq5pKy+nuWZaIKMBrhfSNQ31aqYGcTzeiAbmI1/n7/AfLJcpaW01TAkk7wujAK9X0mYwU0qPzjp1McafBJhv7DyCtAySAsx5VAENDUBqWtiTA0HtS+A54WZo6DMfHLhm/m6TDw1B9gAgOmJK6Y9uZYkxPgCI6EBgq4B6YFogJYgbnnYIiAJUDvDVAVUCWgWzBuSGnW+vU0pfuiNLjPFHApLCfG0FVIKJPLYEEgLspvOU0mdvg4dh6L5++uAeYbz/9e/XEPyjuxjjRwYTgbWAiuaOamINfRDIDYOZQT62Brgv2MlJZYgcrAQUjUe31ffARDMayawzyDsC0TTr51++W2P5byvf/PbPCMRj9hnmi6CpFCoaOqkwJfOOipPZEJB3lpNZE2Ip1Mk5vRCgHOaboaEdBZqXwqhYU8OITLozQI7mfEiQo4zljeVKMtV3Z1HM0jyztJlEw3tLjodr5sYAGVr0izUyljuWL92f6s1B0omGBnIGlc9/LfOeaWL+VVNKf0qVPbQ21pp9jPEHYu7U5HkfKjokvuJNz7U5N9fOkwfpqM9ikiGYuqidvM9Eg3TLvB/PAaRVr6kdlrlToKPMuo98Mwsnr3pzaUD+fKIgHUA/G9qJ+GQJlpnTzpeDhGPJQensT0mkek7tQkBNJ4TMXJvx0AJQBbuvnz7Ae6cmYz2VYZO0dIg0dCcZWmeMJe/I8U7y3s8F5n3/+7/dGvL087dNPPzk3f8j3p0P6vk66MybZ5EWfOkvdJIgc94l+Sv1RhrJtTPLzMxRxwqHRvuuSd6vCLJlOVM7raHRzNwpYd6prqKVpygV2gmZoUyiMZU8Wv92BM3vyQs57s0jf6uJzJxfUxNfDNC1hYRzEtSOqb2aFxfNnN/k2gnHZcdawGgtSjsQB9eg3XJC1yjR4XzgoL2zHrhEEzfa4+YhrWcuMkH95aWYuNaeqd2iadNr1B+KHewVS5Dm4/Ra6welB69RAuMBxfPa4iZODZUcEL++dqhB4DITy4GsCvH+QPP0hqLysMaOlzX22V+GUpj8AXXn15XIIHARYaKdXtcOkQvazaHu6KAPLh64Uhk8m10jgHXT0EKNzNeSmfMMhmkr3mIbX3dB8h60hwQhoK7PNHMUFwNNvWSj6TmI0B43j+h4gIaEXKMkbyxm7jOzSCBFJ1Rq6k8rvKpoUY7SDsQBmjzSTH69ezeM+s1LMfUA2jG119routgFRwVFwtLIrr3laUXtHPNumL8WKLDo9ugriSDsduO7Of5q9br3Xpmba0Bqn6vY1fG9sKuDb9HewvU4oNk2kGkfeBN5EhpuAal9rjLCTdvgCs2cOyErOrYqwsEDwAuk9rmCemvxlRlslu259BaSbtyiYSnvssmjbTJDo5ieQ4kUO0SiMF4mM+fhLXBLNndAknmjyNiFhBDGCjZxUmvLWE9lJOIJVF0MF3mfSc+5N5/FxkxBSQsJIZzFoohUTxJjCZ2MNk/3DtqTAHSMRWzWfx5KFO/9sSCgShy07xLIpwZyF9aBBvKnDFQByWMqLaBdqZkjz45it7tzAGrUxwrz04JRd94cvYHjWwm1wKoc6vfFiFDrj+xsxL586idRDKUWULUISPW8tkBTSmTuD1Jlx4Yca+1zGv5oIB8c5m06n21eIH8NJAXKY7ZfDKAHN/uxPG0hhkX1cqDIxMVh0SioJGTudN6OTL6/xZvLMD2zo/Hz9k8IRCQbQEDR/nYKtL/9R4csaIOSBLS//XuMvZeoBmh/+18j29w1oPH2j1u+XW4lQKMCNl77f8F5gQYFKILIz9f+l0IpDU0Vq0CWwNSAcpjB0FZ08B8G7RnXVrekyYUGjz8jzbtdIEcpWRUfSKN44zpSoagslkgQJZDox7YWZCSog2NGUw1Sqqz3GbSvOypjU6S9kkaWaibSUAQYAVwsWNSApEBqxDL7oPStFsQazdSgalq4N0QOpFY0LQ0FgNFzUv3Qio0E0wOvCUipsvvkERxQR5FiNvmzmmgwO2C+FkR+fhSYPK/A0kLluVQ/1HfWnNO89oKoVbZVnkFJQ6asPUdFg+E136YQs6yxYWAo/J4XolaOB1gzcz6kZnZCGbwsDV4pTH4t3VsFYpb/AYjowKzPWMi5AAAAAElFTkSuQmCC"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.9802"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="4" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{02592fa7-3c03-4979-966a-9d51ac00c282}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="fuel" filter="&quot;fclass&quot; IN ('fuel')" key="{77c93bef-f34b-4332-8bc9-95773699285f}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.980208333333334" shapeSizeY="10.980208333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="1"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFMAAABTCAYAAADjsjsAAAAHI0lEQVR4nO2cUXLjNgyGRdrbqzhpH9rdnmu7Z9n2XNmmD1tvrtIkVEcZ0QNB/w9CtGTLsTGjsURFFPkFIEEacGiWl6A+dXnpHpPWuGb3dPmsEk5UdyCfpTJLEDyrzII9i2wXqDOoT1QWDMAlqB5gXljtWjUzgDo1tCnnXpht5bmsq10LTKaBQZ3Lsmjc00CZIEiyLBn39Lms82wwS+YbjCM6YFqaacFMoMwLtT0HTAYyFMBFAyYCq4UBRDDTBMC67pNMQJY2RgJRfqIyC2h+BxorSxCTOA8EagL1y/dMBjOnNkYFDl2j8mM1U4JL4NDllrbq98yumSWQsQBuQ8otDfVqpgWxO16FBuYjX+e/0f+w/E6mtdUwGUg9FkYCb2OUDWCmlB6cbWpijL8TmK/qPIKyDFICzHVUAQ0zgLS0cCMOBHUzBZ4TboaGPvOhgVvm7zb5MCPIDQCIjphS+rtZWGKMHwFEdCCwVUA9MEsgGcStLjsFRAJVA3xxQGVAq2DWgNyq87frlNJjc2aJMf4mQEqYL3MBZTDRjM1AQoBNf55S+ubtcNu2zf2XvdvD2H+9fwnB793FGD8pmAhsCSg1d9SSkuuDQG4VzAzyYW6Ax4LtJ6kMUYNlQJE/+tZ8D0y0omFmnUF+EBCLZn33x79LbP+9yY8/f+6AeMw+w3wmmiqhItfJhMnMOxqTzFaA/FCaZJaEOBVqPzk9C6Aa5mtBQxsJNG+FSSktDSMy6aYAsjPnU4LspHtf914mfXsPFqUszbNKG0gszN5s4tGauS2ADHOMizXSvbd7P7vft1uDlAsNC+QAql7/lsx7oIn5v5pS+oc19tTaWGv2McZfhblLk9djKJ2Q9I63PLfW3Fo7Vw/S0Z7RIoOYOtVOPWYiJ71k3g+XALLUrr4fJXOXQDsZDB/5ZhZN3pzNmUN+t1KQDqDfCtqJ+GQJJTOXg68GCX3J1hjs1ySsnX2/ENDiJITM3FrxyBegBjb3X/bw3tqka6fhNrGtQ6Sh0MyRCsNNDeYG3Z/J/akV1t6+fwgkYzQy8yxoBtdAL26cZGK0G2mk1s4sAzNnxEdgz7EneQ7p+1lyjQbaGXr6Ghpyzn/ql4yPc2rl01+/TH5m9/l7cwqHvt8M6Rz4/4gzP3DikcnqnSI9bs4mTxUgj3muQqwl5Yhd1ig23Q80Fjno1kbC3Jq2JMSuH3o/tOtvv8xks7i8br1OO9wlucQZnInRD8TB5bSXJqFrlOiYfKDT3pQemNvE1ySkP24ebD9zVAkaL89p4k8LjJ+oP32/qWnLazQesgF2dfJ0ulmdrsfltTUOsgdXIbveA+iAngCqBgnF87XFamUnXKoTaampoWjM0wAXh/p0BAikoQuskBADcwJilVyE7BZYYk7lUYL5vnyf46WdClM/YEZ+XYm0hAuFiSK9rh2iFhTNYUZ0yAdHD1yptJ5g1whg3TR0okbma2bmuoK2D8UbhfE170j2oD8iCQENfUUzR3kx0NSnBJpegpD+uHlExwMyJeQaJXlzMfOYmYWBpJPQmkx99/l7tfNu9ANxgCaPNFNfH740QuPmezH1APrR97cU6DqKgpOCMmFlZtc1yauRKDAa9qSZa+Is/7AqhnzNYrSfZbJBZp4JaFBRHwc+i+wqx7dTbGqIDDcrwHVg5vL7XxQKowMR3oIRWKTw3QWGyDCt7L/ilcEHOoFAg4ZmzjTzkMrBtHO/opndI6y9IkUQJVixGX0U0cHMG2XGwhlx//X+Iiaprp2GJ+JJVB25i3rMlOd6Nh/kxvRxOCMJIUB/dG3C2ilyLDVQ5Gs2NU57IkC7XMSLm91/8HHy04SEKuq0HwrEpwXyEAmGHPk1AzVA6pzKEtBmqpkzf1ODbS4BaKE9pTQ/Kxn14Bqhb+DihMSqnOr3WMhQ25x5sqFjuYjDfJmQUDVKSPV8bYGWlMjcP7LGdh05l9vUp05bID86zLs4+bzVBeq3QEqgOmf7uQD05Gbfvc/aiFFZvRooMnHqFnWC3oTMPZv8Ld+88eebyzIWoymh3n4JQQizARaOLaHefqNDibWziwKUGNDN7ddjyrFENUA3t9814jAbB9B4+8UtX5TbFKDRAKvLr+634LxAgwEUQUQJnkv+SiErQ0vFKpBTYFpANcxQ0FaW1InSQ+S7rd0ttriw4Oln2LrbBbKTKV8ztKJTunONaFA0NksYRAYS/bNLGzIMautY0VSDZI31PoPiuqPhmyLtZRo5VTORhiLACCBa0UwGKYHUSMnsgzG2liDWaKYF1dLCoyFqILViaWmYABg9x9qHdmwYTA+8WUCyxh5TR3BA7YTlbOpnLbFgNsB8SxD1+Vlg6rqCKguV56x9aOysOZd1HQXRauxcdQajDJmy9ZwUC4bXfGeFmGWJCIx24t95IVrv8QCbzZxPqZkNeYd+lwVvKkx9ze4tAjHL/4omxrlcVQkvAAAAAElFTkSuQmCC"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.9802"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="3" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{f00483aa-e171-4a38-8e92-197ec6875625}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="food" filter="&quot;fclass&quot; IN ('restaurant')" key="{eb94dc7b-4c8e-4082-a7d4-0be94953656e}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.980208333333334" shapeSizeY="10.980208333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="1"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFMAAABTCAYAAADjsjsAAAAHGElEQVR4nO2cUXLbNhCGAUjpi6MztLlAW6cna3OONCdzmvYCSc5g+6W2wQ49hLtc/v8uSJESZWlnOAJBEQQ+7QILCMsYlpeoPnW+d41JY5yzazp/VokHKjuSTy/PEgTPyrNgzyLbBcqM6hPlRQOwB7UGWC2sZq2aGUGZGtqYdC3MZmJaltWsBSbTwKjSMi8Z1zRQJgiSzMvGNZ2WZR4Npme+0ThSBUxLMy2YGeTVQm2OAZOBjA64ZMBEYLUwgAhmHgFYl32QAcjSxkQgyk+UZwEtz0B9pQcxi3QkUDMoXz5nNJg5tTEpcOgc5e+rmRJcBofOt7RVP2d2zfRAJgfchuRbGlqrmRbE9ngSGliOcl6+o3+w8kymtZNhMpC6L0wE3sbI68HMOd9U1imklH4jMJ9UOoG8AlICLGVMAhpnAGlp4UYcCOpmDLxKuAUa+iyHBm6Zf7XJxxlBbgBAdKSc819hYUkpXQOI6EBgJwGtgemBZBC3Ou8QEAlUDfCxAioDOgnmFJBblX4+zzl/CUeWlNKvAqSE+TgXUAYTjdgMJAQYunTO+XNtg5umCfcf3lV7GFcfvz7GWO/dpZTeK5gIrAeUmjuqief6IJBbBbOAvJkb4L5gu0GqQNRgGVDkjz5XvwYmmtEwsy4g3wiIrlnf/fHTEst/z/L2z28tkBqzLzAfiKZKqMh1MmEy807GILMVIN94g8ySEMdC7QanBwFUw3xyNDRIoGUpTIo3NUzIpIMDsjXnQ4JspX1e+1wmXX1fLEpZWs0srSfJGb3ZwKM1c+uAjHP0i1OkfW77fHa9q7cGKScaFsgeVD3/9cy7p4nlV805/80qe2htnGr2KaVfhLlLk9d9KB2Q9Iq3TFtzbq2dqwdZUZ/BJIOYOtVO3WciJ90z75tTAOnVq2uHZ+4SaCu97qNcLKLJm6M5c8jvVgqyAuhnRzsRnyLRM3PZ+WqQ0JdsjM5+TcLq2bULAXUHIWTm1oxHPgBVMNx/eAevrU3aehpuE1s6RBoKzRypMFzUYG7Q/ZHcn6nC6tu1D4FkjAZmXgSN4Bro0fvJ3afvs5Rj1BtppNbOIj0zZ8QHYJdYk9x9+t47Sl7NfUtJ107PNeppJzLzkl6tVs4NdIJ2QmYIjl4p0v3m6mS3nIZaU8oBO2Tm+lya+MBBtxYSlpTb33+cFShqR9deaxSnZq4vau2Max/Bd3sANdqBOFQ57d4gdI6SKgYf6LQH74Y1mPhSQtpTzaPN2JKFjLLE9kN75Jz/mXMU31WapO4bvTKs709dpksp/RxC+Lc75BJdbzUe9Ye0gz1jiWw+Ls+tfpDduFq53VMrDdEgoWyPpZG3hmtTC6X93pKzoLEaygYgVMA5SyRceuK5O6uGuDusVro8PJivy/fZX5qxMPUN5s6vMxh8GIPGgol2eq0e4oEF7eYwd3TIGwc3nKk0NZtdE4B10dCRGlnOmZnrAppuK95gG194RXIF2iOCEFDX55o5iouBpj5mo+kpCGlPNY9UcYMMCTlHybWxmKXPLMJA0kHotZj6FW8H4gBNHmmmPn/Z+YX6zddi6hG0o2uvt9F1sAtOCoqElZFd5yRPRqDAoNuTZq6Js/jDSXvI1yxG/VkkG2RWMwD1Cur2gb96Sf9HuFkbXHtmLv//RZsO9C7h578x2E7hu5VvJRyjld1OYvk3hQ4g0KChmTPNfAnlYNp5dWIjO6uvCBFEAVZsRO/NgIJh3igyFo6IVx+/nsQg1dbT8ERqAlUH7qLuM2Vaj+a92JguKGkgMUboj65NWD1FjKUGinzNMMVpzwRoG4t4cqP7W95Pvh8RUEWd9pcM8WmBfAnrQI78moEaIHVMpQc0jDVz5m9qsOEUgDr18cL8rGDUF9cI/QOntxJagVUl1O+LE6G2OfJgQ/vyrp9EMZRWQNUgILXmbws0pUTmfs0q2zbkWG5TFzptgbyuMG938HkuC5RvgZRAdcz2gwP04GbfPs9aiFFRvRooMnHqFrWCnoTMvZj8Jd481Mebyzy2R1NCvbwJQQizAbYdOxpAN5d3dHBBG5QY0M3l7TH+XqIpQDeX9xr55m4BTZc3btXtchsDNBlgdf7ZvQuuFmg0gCKIOr30WwpZHpoqTgI5BqYFVMOMjraiQ/8waM+4tbrFJhcWPH0Pm3dXgWxlzN8MjWiUblwQFUrGYgmDyECiH9tbkGFQm4oZzWSQrLK196B93cnwTZH2Mo0cq5lIQxFgBBDNaEaDlECmiGf20ehbPYhTNNOCamnh3hA1kKliaWkcARjdx+qHVmwYzBp4s4Bkld2njFgBtRUWs6nvtcSCGYD5ehB1+igwdVlR5cWJaVY/1HdOScuy9oJoVXauMqORh0zZuk+KBaPWfGeFWGSJHRjNyO/VQrSeUwNsNnM+pGYG8gz9LAveWJj6nF1bBGKR/wCYUb1WLdvhnAAAAABJRU5ErkJggg=="/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.9802"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="2" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{483d18f8-9200-48e2-b712-ec0b24b23839}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="bank" filter="&quot;fclass&quot; IN ('bank')" key="{fba5bb62-3758-4818-83cd-9a8f56da5620}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.980208333333334" shapeSizeY="10.980208333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="1"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFMAAABTCAYAAADjsjsAAAAJXElEQVR4nO2cW2gcVRjHvzm7aWIvaU0vNqTUKJQmRTRpFa9IEUsR79Q3b/iiINiCT6LioxcQoeKDCD5YEPvgk9CKiNRCRR9MrNqaisba2qZt2rRN0jZtLrMy25ndM99833fOzM7MbjR/GHbmzO2c337fue351oHs5aBPnG46x6kkHHPncHqqcnJ6tsN8mtIkUfCkNAl2Kipm8EwHfVJpjgDYBNUGmC2sUqNapkM8E0OLs28Ls5RwX39WqVFgchbooH09TQnnMFBOFCQ9zRXO4X39mXWDaXJfR9iUBUzJMiWYLpFmC7VUD5gcSMcATgkwKbBYHEAKphsDMH52Lg2QZI2Kgah/UmkS0OAdVF1pguhq+w4D1SWer78nNpg0rVEhcNQxlV6rZergXGLD6ZK14vekbpkmkMoArsCkSxZqa5kSRG+b0Sww2ILj4Br8hQXv5Kw2MUwOJK4LFQOvIKSFYLqu22eZJ1BKbWBgzqB9RaQFIHWAwTMSAXVSAClZYUHbKKiFOPAs4QbQqM9gw8Al97d2eSdFkAUCILUp13V/goyllOolIFIbBTYRUBuYJpAcxCJOywMiAxUDnLaAygFNBDMJyCLaLx+7rrsf6iylVI8GUoc5nRZQDibVYnMgSYDg77uu229b4FKpBN3bBqx7GAPbu6cdx753p5Raj2BSYE1AWXencmLq+lAgiwhmALIvbYC1gvUbqQAiBssBpfqj5ezbwKRGNJxbByCbNIhGt+7a+lsW039lHXp/nQfExu0DmFOMpepQqa6TCJNzbyU0MkUNZJOpkckSYlyofuM0pQHFMGcMFgo60GAqTJdpaKgolwYDSM+d8wTpyXuf915Ofn4rHoU8zWaUFpIytN5cw4Mts2gA6aRRLyaR917v/dx5P98YpD7QkECGoOLxr8m9Q5YYfKuu6/7MZTZva0zq9kqpWzR3110e16Fsg4RnvPV9acyNrbPhQVrkJzLIYFydtU5cZ1KddJN7980GkKZ8+eUwubsO1FOo+ghOBsLkxdac65B3NShIC6D9Buuk+ARyTG6uV74YJNmXLAmVfSOJy6dfLgqosRGi3Fwa8egvoDII3dsGyHONJi+fQreJmzqkLJR0c8qEyUkNrhvUXafuT1Jx+fXLR4HkGEXcPBDVgmOgs66e5CTkm7JIbJ2BQm7OEY+ArcecZD3kl9PUNQpZJ+Xmwf5/3iprsE6SGfUQPFOE683c1FRwoHPFPLjxuma4POXC4VOTcGxkEtzEay5iq6D9IIdbc4V/1Qxgcs19yEKpDro0kVCLHr51Mbz+RDssWRD+/v44cQVe/fQ4/HJkAtKUVw48H+qV1x9mcq24flyy7bRHugFZtuDPbFwK7z67KgLS05r2Ztj58g3lzzQllIPiYNVpNzVCmWvx/AK89MBy8ZqCcuCVx1dCTrJpfMhOO5huyNrF7+paCK3zqxY5ePIKPPTmn/DYO4MwdHYqdF1zU7qDLaY81jy4+czIQ6j6MgsXv37ZvNDxZ/vOluvJgWOX4fMfzlUz7gCsRtfWKqo8frlZ19aPi4YL2G8hK7W3eVOkVZ0eq05B7uobDVnn+YteQ5uLuIYndF6yLO7GTFVAb9I97+/hyfJWB2GQpIqNYpHrVrXApp5WuGn1NaH0Bzcshq5VLaG0nfvOwanzVQvNUaKFUpaJAeYCdW1HC7y4OdqKb+5pjaR9smcEchbFQGyAuIc0lM6MT+dZV8biYWqNcxu47eobhT0HxuG1LSvhkduWVNK90c43v45Xjl28LDVfleLCxDeIK7/SUtvCInR1tEDbonCWOlc0Q09n1RKPnJ6EsYncLZNiEGGi55xa6ZWbZd65dgG8/VRHJP35TcsANlWP39g5BIeHr0CdRK3mEFd06DdGbqi3Dh2/XI/XiqvfdMvEsOpiod//fhFe+PAoPL2xDe7pWlhJ/+jrM9A3eKly7I2EGs0ig2PdMjmoVy+8uhQvsowvrdyePD8F3x4chxPaCMfTgaMT5fRgm5zO7nulyqMFIVCGFTrmGiBuCynOQlNbTc+UIjNEesf+7u6q1e76cRSGzqXXeWfKY82jaHGDHhKSuY4jOO3XVsfqXpfpufuWVo6/7B/LI0vc2iJyrRHr2sya7sxc3dOxkTDMJ+9tg9vXLID7b14EW+6o9j8nJl0YOpveOF0oB8WBdHnKMvFxZeWXV3/gqbi0Xf27gQswemmmPEnsqaOtCXZs7Yxct7t/NNXfgqhy+PWlaaFrZBWcLioSVo/sylRjEzPwwe7Txmve+2IYcpAUKBCp9nQ3x8S5+MNEa8jjaMfeEdj68T8wPDodmY7be/ACPPrWYHmMnpaE/HORbCQz3c31k6Sb+67em8dChK/2j5W3Za1F6Fw+r1xH/nVqsvyZh7QIN2mBa8jNgx/LwLBuvUnb5nErhbtm4WIEzir9n3gntZXEOIAAgybdnLPMSiiH/61l3rJnLS6/WoggFWDFteihERAI7k1FxpIt4sD27rpNNsaRl0+hJ2ITqBrpLgYwpW5R8BmKjfGDkiJyHCe78V6K4vKpxVhioFRfE5J02l0GqBeLmHnrnmM9uT5GQFWk0065OViArIR1UBMgjQxUAIljKk1AIa6bc/1NDBZmA1BDfkxhflIwaqVrRP0Cp2IEVgWhfvsNEWqFOjc2bF3u15NUDKUUUBUJSOXmM7lGSHL3Xi6zXkHq1W3yQ6clkL0W7m1sfMrPIp4vgdSB4pjtKQPQ3N3ee580EYOiejFQysXZbpEn6k2UuwcuPxdvDvbx5noat0ZThzr3TwiaOB+ggFLr23Wghbn/6OBFLVDigBbm/j3GvJYoCdDC3P8amd1dAqrm/nHLbpVbHKBKAIvT/3f/BWcL1BGAUhCpAM8s/6WQS6OGiolAxoEpAcUwHYO1ckGdVHiI/m5pdosbXEjw8D3cuNsKpKc4PzOUtELhwoGWISVMlnAQOZDUl22akOGglixGNIlBcpm1vYda162EvillvZxFxrVMykIpwBRAakQTG6QOJIlMbu8IdasJYhLLlKBKVlgzRAwkqSQrdWIApu7j8kfN2HAwbeClApLLbC3PcCygeuJiNvG9kiSYQLivCSLerwtM/CwHpTkJ97n8UXVnkn39WTVBlDKb1jMdIY1yZek+XRIMW/dNFWKgLFZglGJeZwtReo8NsNTcOU/LBOYd+F0SvLgw8TF3LhOIgf4FiR19rNV2HYoAAAAASUVORK5CYII="/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.9802"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="1" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{99d943a0-a4fd-4e16-8fea-7dd6d6df6c37}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="clothes" filter="&quot;fclass&quot; IN ('clothes', 'mall', 'department_store')" key="{de250ae7-2950-4702-a18e-e47e532d3ba0}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.980208333333334" shapeSizeY="10.980208333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="1"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFMAAABTCAYAAADjsjsAAAAHWUlEQVR4nO2cbXLbNhCGCUjOH5tnSHuBtk5OlvYcaU/mND1B2jPI/RPbYIcawl2t3ncXoPghJdoZjkDQxMfjXSwAYRWa+SWoT53vPWPSGffsmc6fVMJCZQfy6eVZguBZeRbsSWQ7Q5lBfaK8YAD2oJYAK4XVnatmBlCmhlaTLoXZjUzLsrpzgck0MKi0zIvGMw2UCYIk85LxTKdlmavB9Mw3GFcsgGlppgUzgbxSqN0aMBnI4ICLBkwEVgsDiGCmCsC67EUckKWNkUCUnyjPAprrQGOlBzGJdCBQEyhf1lMNZkptjAocukf5p2qmBJfApfMtbdX1TK6ZHsjogNuQfEtDSzXTgthfL0ID85Xv89/of1iuk2ntaJgMpB4LI4G3MfIOYKaUHgrb1MQY3xOYLyodQV4GKQHmMkYBDROAtLRwIy4EdVMDrxBuhoY+86WBW+ZfbPJhQpAbABBdMaX0ZzOzxBjvAUR0IbCjgJbA9EAyiFudtwREAlUDfC6AyoCOgjkG5Fal9/cppc/NyhJj/EWAlDCfpwLKYCKPzUBCgM2QTil9Ku1w13XNv7/9WDzDuP345TmE8tldjPGdgonAekCpuaOWeFMfBHKrYGaQD1MDPBXs4KQyRA2WAUXz0X3zS2CiFQ0z6wzyRkB0zfrx1x/m2P7by93vf/dASsw+w3wimiqhoqmTCZOZdzSczFaAvPGczJwQa6EOzulJANUwXxwNbSTQvBUmxVsaRmTSjQOyN+clQfbS19fXy2Ro76tFKUsrWaUdSHS8N3M8WjO3Dsgwxbg4Rvp6+/rZ86HdGqRcaFggD6Dq9a9n3geamP+rKaW/WGOX1saxZh9j/FmYuzR5PYZSh6R3vGXaWnNr7Tx7kAXtOVpkEFOn2qnHTDRJ98z74RJAeu0a+uGZuwTay8HwkR9m0eRNb84m5I9nCrIA6CdHOxGfLMEzczn4apBwLtkZg/05CWvn0C8E1HVCnhbqCfmb7HiQ9+4mWs1Iaf/45zW9+/B2yqLpqknMP/vrK5jYQ2eUATbOXPJGXG+Y936c0LwlRC1TQmUefvDuXwVUPanX+6AH3jwL2/CVy8nVQJY8rxGj3SVftWTZp3NBaGCFU6Ol9yR3QgunhOhJ388Y408FDihD7bZkNh/W0so5xkZP+vYTc8/9zt8j5SspZvvviRCE6CwlF5d2QY1UIkFqby6h7kVPjcxdIzRBtzYS5pI5NBf1Y+gvM/NG35dO2uEuSS9LbmDsPrydbQgw+oE4FE3aPSe0muwWHkeFeM6Hrs0b74WlTbwdxsslxk3Sn2IebD/zqBA0Xs5t4q0CODdQ1J+h39S05T0aD+kAu6S0ZBm5kmen63F5b42D7MVVQO7WBapBQin52mJRaY2NjXPXUOaAUAGzS1uwQ7QSUMTAdECskEWkrdhqW1FDTR6eN5597tOO3K/Mf9u/n8tYYC5q8ogFL5gnv9be+N0to6WIQWfBRCe9ZtPMdsId9AXNHp3mME90yBePXjjXryJ28wI1T7/JMVPDmlVD24VWNX25E46hpkbme2bmuoBuOIp39IVUTYvaheeGtfWh/oggBKRYrpmjuBionTUHTduVNnhr6iX9KeaxLXhBhoRc4hbaqcLOFsGzRtS0yZnuk0z9XMXoB+IATT46A6zUyoTGzRpTP2chhxHeFxx0PToFJwVFwsrIru9JXoxAgaNhT5q5Js7iD0edIT9nMdrPItkgM2TmzPlkU+/P4XzzEv+PcLMOuEIz107Ii479ZrTzrl4rtXY2yJt7mvkaysG08/bCPDtrrwgRRAFWzKMfrIAaw7xRZCz0iLcfv1yEk+rbacxESgJVj6aLesyUae3ND2JjhqCkIwkhwPnouQlrp4ix1EDRXLMZM2lPBGgfi3hx4+cdP5P5riKgik7aXzPEpwXyNawDTeTPGagBUsdUekCbWjNn800NtrkEoE57vDA/Kxh1n2aHD2JFYFUO9fvsRKitchxROBs6lg/jJIqhtAKqjgJSS762QEtKZO73rLF9R9aaNg1BABbI+wLzdp3PvixQvgVSAtUx208O0MXNvq/P2ohRUb0aKDJxOi3qBdWEzD2b/DXevCmPN5d57IymhHr9JQQhzAbYcWwJ9fobHUqsnV10QIkB3Vx/PcY/SzQG6Ob6u0YcZlMANF5/cavslFsN0GiAjd/7b8GVAg0GUARRp+f+lUKWh5aKo0DWwLSAapjB0VYW1InCQ2Td1u4WW1xY8PQ7bN1dBLKXmmiJTnRKd64RDYrGZgmDyECif7a3IcOgdgUrmtEgWWNL30HnuqMxN0XayzSyVjORhiLACCBa0VSDlEDGiGf2wRhbPYhjNNOCamnhyRA1kLFiaWmoAIzeY+1DOzYMZgm8SUCyxp5SRiiA2guL2dTvWmLBbID5ehB1ehWYuqyg8sLINGsfGjvHpGVZJ0G0GjtVmcHIQ6ZsvSfFglFqvpNCzDJHIGlX+XelEK16SoBNZs5LamZD6tB1WfBqYep79mwWiFn+A+WVGGpHfDpvAAAAAElFTkSuQmCC"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.9802"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="1" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{49cad513-f157-499e-9149-5cf9581d3c1a}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
    </rules>
  </labeling>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks type="StringList">
      <Option type="QString" value=""/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <fieldConfiguration>
    <field configurationFlags="0" name="fid">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="osm_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="code">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="fclass">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" index="0" name=""/>
    <alias field="osm_id" index="1" name=""/>
    <alias field="code" index="2" name=""/>
    <alias field="fclass" index="3" name=""/>
    <alias field="name" index="4" name=""/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" expression="" field="fid"/>
    <default applyOnUpdate="0" expression="" field="osm_id"/>
    <default applyOnUpdate="0" expression="" field="code"/>
    <default applyOnUpdate="0" expression="" field="fclass"/>
    <default applyOnUpdate="0" expression="" field="name"/>
  </defaults>
  <constraints>
    <constraint constraints="3" exp_strength="0" field="fid" notnull_strength="1" unique_strength="1"/>
    <constraint constraints="0" exp_strength="0" field="osm_id" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="code" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="fclass" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="name" notnull_strength="0" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="fid"/>
    <constraint desc="" exp="" field="osm_id"/>
    <constraint desc="" exp="" field="code"/>
    <constraint desc="" exp="" field="fclass"/>
    <constraint desc="" exp="" field="name"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValuePolicy/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression></previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
