<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis autoRefreshMode="Disabled" autoRefreshTime="0" hasScaleBasedVisibilityFlag="0" labelsEnabled="1" layerType="Vector" maxScale="0" minScale="100000000" readOnly="0" simplifyAlgorithm="0" simplifyDrawingHints="1" simplifyDrawingTol="1" simplifyLocal="1" simplifyMaxScale="1" styleCategories="AllStyleCategories" symbologyReferenceScale="-1" version="4.2.3-Belém do Pará">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal accumulate="0" durationField="" durationUnit="min" enabled="0" endExpression="" endField="" fixedDuration="0" limitMode="0" mode="0" startExpression="" startField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation binding="Centroid" clamping="Terrain" customToleranceEnabled="0" extrusion="0" extrusionEnabled="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" symbology="Line" type="IndividualFeatures" zoffset="0" zscale="1">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="line">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{e816874e-b643-4d1c-ba6e-11c8957dc93c}" locked="0" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="190,207,80,255,rgb:0.7450981,0.8117647,0.3137255,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{2496e264-d718-4d46-8f0e-90e42a00877a}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="190,207,80,255,rgb:0.7450981,0.8117647,0.3137255,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="136,148,57,255,rgb:0.5322194,0.5798275,0.224094,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" id="{c83d8c4a-9489-49b8-9119-d7d30e0bf22c}" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="190,207,80,255,rgb:0.7450981,0.8117647,0.3137255,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="136,148,57,255,rgb:0.5322194,0.5798275,0.224094,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" forceraster="0" referencescale="-1" symbollevels="0" type="nullSymbol">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <labeling type="rule-based">
    <rules key="{fea7f793-d27e-44b2-a5c9-a26d90c8b2b1}">
      <rule description="hospital" filter="&quot;fclass&quot; IN ('hospital')" key="{d60119d7-6a16-4fd8-8eaa-2db62c8081da}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="9.7895833333333329" shapeSizeY="9.5250000000000004" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="0.972973"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAEoAAABICAYAAABRGGN6AAAF6klEQVR4nO2cTZLbNhCFm6TmxzlENuYmmyxS8ibLHC+pyiaXyR2MVdaTQzipxB79MaUptPL01A2AIscjzOhVocChKIr4/NBsUQ03Mr8auQwNlzSopuB8zQuCGeaC10x8T5M5z9j9pRrO3D+cC20x4tjG6XOvWX/PLc85g3EdZ7msBFST6LVJZp91vqlKDXiAxvtKzzfqohmKBaN1tq33PpcQAvY7Z5uP9xx4UGoA1kBbAtXQvpaO4/fnPnOMPLcglB28htu4z3r/6GDbJMC0se+c/W1iOs4pdogC4X7r7Oem5yyOUSk47cNy+bdcoPoQvo0QuLWx38a+IWgy1lEpB7UR0l9ywepDeA+AttQQ1i7jsOwdCWNNG1sXIX2SCtSH8J2IbAxQmww0odjlgmIndbVBUvUhfB/BrAESbiMsjmFHrlLnZAP3Q2WQ9npYLv8QkTsRuReRWxG5if0iticDGHfvkxuQF8wZViv16p2IrIzBo2va2Ovr2bue5agutlp1D//YTSYBRVj62gkoL6Nu53LU+48fi4/988MHmREU53EIZkvTTsBVB3ctnKB+dKeT+h3FTtIArrNlF3uEp3qCxY7yAnondccooa8texALgLVNBPIjR1nCaddJvbojQJoaYD7FMexEPPVSGXnNoHYAZgPpwYYgcYpwiFMLJ+m0MvNadRsBrSOYm7it8ZfHqN8JUQ0DsB6ptK8AFCeammwiLOuJh3iZOW7zNKxViwiqo2wcQZnZOG7nADz3s6SvIXRPVwjoRGi1lJtaqVcMh6daW+IqKzPHbe4nZ9ylKj1nQQbP08yC4431kJlbwZy3m8qnnj6qRgd5yaUZn8bEqJrFgMQBVBSj+MTYS+WwrDwx56KT8ZYE6UbqljfN+JikSu9mjbwOeV/8s6r5tj9Gk2PtWwE1WVdQhbqCKtQV1DMUkk3+IeCFflyYRVdHFeoKqlBXUIW6girUFVShrqAK9VZADalqujlBDfL6NApc+wYgDYlmHVucmU9eN3Jh2TaWGkrhioZhrKPOms8XJqu2XApcNqRAWQcOlcOyCvRT9eUmrLYAktQKqg/hZyqPxspfr748OfWsOYuFV7s+hB+kPmGpT6oYPxWPzR9AWUfQ+hB+lErUh/CLAYqL8bMrFkqmHrtqu299CD/JhasP4ddYMr2OPRbiIygrbok1Bb16Ta0AuY3tLhaN7ushv9m3h+Xyd7kw9SH8FoE8isiX2D7H9q+I/APbn6GtoJmu84rGulhTtCBQ9xGWAsP+Ha0S0LqkhVHVNuXnI5we6Ayty1RQKwDxheDotsJ8jO/Tqjxc8vEEShNOrKnG6cblxhtoK3AfF4puI6TNzKA4Zdk5oFZx8Ars0XANBvhscE89M7cgdfFCuLQPS431or3j5ij84IJ6LGZVUApIHaP71DXsHK7bPArqCMrLWHdG2fHKqC9CqDrlsBSQHYV9KRwGhas7+fp0CmLDAM93wVRQF556Kl0hqTXYW2hrZ22JXrBW3uK0ZEeNhcTAdAAMCpea4VTD6ceOsqZdcuphnMJ4tQOnrI2pg8fpBXhummPqeaA4jlqwcPphupBNDxYFwXLrlFWLA1KnnVUOKKnK2wyc1DXysliFgFAUHN7Z0FXWl+aDvGB+8hVG/ge2No7BFQFa7I5lyl4N99QYZV0jxyu87XPPjhJnib8ZzPFvXM2NYkg3tFop56apU4+vgW/x6JbUMlkrQ8fPyD64UzjWcgehGKGrk6zgnYtN5zpK/87Bshy2Pef7nhWjvIAuxoWxg3ARjrcQR2Z2lNBA+QkBL7DmdGB0HmUeYDhriK2jD/NquKcE8VJQ1jcKhsFu428ffJ4j5TJzhNXEfS2c7KX/yxEeGA7aAmZNtSwkHYQnqwa7dZ44sHusmu6Sz5zTWZbLrHhkncOF4ckabJPIqxgQv/c5lAMmRn7Ez8qTkKRwAE2it9ySc9Ac0Kw74Bhw1uuTK+6Ggtc8mKqv4ShrnwWH35OFdO4AGmPbO8/Y/SUq+Yfz9hU7iPUfrf+D8IOkKsoAAAAASUVORK5CYII="/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="9.78958"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="9" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{cefff544-0be9-4bb1-8875-13ad594073f1}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="police" filter="&quot;fclass&quot; IN ('police')" key="{0a6a2fb1-f5e6-498b-9765-95753914c828}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.980208333333334" shapeSizeY="10.847916666666666" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="0.987952"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFMAAABSCAYAAAAo7uilAAAJ7klEQVR4nOVcPYssxxWt7pn9sH6AA4dNR61/sLl/grMXPKxAgRwZBQKBUWIQDowDgwLbYDAOjKVAjvQDzDp0pEaIVkdGygwGy++93fkQ/eg7Pnvm3Orq6Z7d2dWFomZ2uuvj9Lkfdat6s3Cakh1wzzY8sCzDaQKYRX5LAW/7fQUzc2p1zVA724cEdXmCIGZOrWQL9TZy7fZUbdOc/Wbis/fbEJD2eUPX4G9PDswMavyc95/zCMBBAKWA3Aiwt09VzTMAyMCzmj8z6AokAzLr65z+ZrJ9SmBmTukmnxdl9e1QA21T/7D/aGAhaMzS/D4BvU8wM8cmLgzMxHbO+9qAXEONah4EoOakto/dZmbCLhqQi6Ks/pPaUNvUBYHJZQO1FTYLj5aZWYSRi76MkQsHyFXfdveZBb18OAagqao1h2RoH8lW/lvdcPXe515blz2gF73ad+WsJ8cZmY5YRPDowMycQNwmO1o7irL6Zw+oFQPzvAdyCYw3YJXje5TMzAQzbaLLGCsT2XkBgBpDl5EQKzxGm5kJW4lgLouy+ubAtn8QQrjtCwb6GHcq53O0MOmYzMy8eJJUcE8ibNxJUVaf9YBeCtuJ7GQ1xzlnjwHMTKxyuHTh0NcpjQ2ounJGS8ducmg2q+rnR1zVZNAHsiLKyjFSlNXH5ISQmebVMQSzWmnMZNs61mZmI75nFAItyFb+61AVJ7kUNtKC9jNhM4OTHOGV0ej8aCozPdunnm5OasWe22LBURIB+UKouoVJ1heqPI4Hx6oYmo9hbQzMmCrY7whWHgEQgbQyBjBXirL6nbCZDCgXNDXqwSOIiEUUWA9MboQBxA75aS/E4NGOnRVl9dVo1OJgG4DKq2PxAFXM5fnFMHktiiF8U0h0MMHJSTLAlvWZzEqQc1qfY8KD1+SoURyH2rX8OZYk2WWi8gQglQooBp4JFqK6vS5FWX0RZpairH4DrESVZ9VXBVnrsVeZMsTpdVFqrliHjXgAnlO5EKVzFJNkQNURPPuMzkktQRW4CljEQPmQvVBGAlmU1YupIMRkrIpff/hmOKa0Tf0jCrEw+ezmSM1msjFlRn7f5ByAXPS1ypOiXb2j5p6zOSqYVwc4nonOKkV4RaVsKMfWUW9+aBb8KchFP+8VZO9VsG6M7SRbJgTo+QMwY1DmHIOwwZd9ag/X8bEwac0xYnBWN/l9O4D7FGcu3paISumFlNAo6oCeAqDX/hy8HCkvP+9otPLmXBZDgzkFtR8jCUSwVRpmo8yzb8DD56juKcwczO09JpZep41V7SkpT35HYin8HaD9pv8cg3xQSRlj29TPxbaxFxLd8TfJ+cy2qd98zIBepwH5s8janDV1Lw3nJXYXlLAwg/x6A6soq7/HBnV1YjZ0CMi2qX8RQnjVl5chhBd9/T/6/gKusZ3RXZYqxsxthKU/njL4EwPyQydJLHOWMaxizMRskGVcrHQMfaMoq78NTebqgViaqNZd6u6mZxqy8kXPSqxfQnnV3+cy0ztpy5v6u+9tU/9kjkk9EJAfEeP44KxKHON3u2cnBqbatQsi5WTx1i6T3Tb1szkmd89A/l4AtDc38Z1LGIoz8UnwU1FH+FZtU/90jkneE5B/FOQwVV1RUec+GZcdmEs6f6MO3KtObynbvmqb+u3OlvZbCCcnbVP/pR+3IsYK7J+VWyg4dzc5jGqOQCrqI5Dc2Y2VtqnfDScmbVN/TCDgXNQ88G82V96s2/MtQ2rOT3EVAzL8vzyIV4/04WkXjt88tAco73pavbdtEejwvNXITk7Lqf3lxYm8QsjChPAYaaAisApQeUbeJs5vIeD5G9v7yPrGYlu/ixPNzLNmGaAMnsdOxcw9u8ksUqw0MWauHJbmJwwmqrhnml4NsFJ59jsYeUG71azq6PViqvJgqyCnLxX2eDaf54VzVioe2JubsB3wAnZWlRvrvCirv4YTk6Ksnjs208aNIOJ8Yuq9B6rnLHCZpOxnDmfJFxB33hwjAJ+J2V6AbqApG3mbCmQsNOIaVV0xdA317CuZmVZPatwMGgMdC4UC1zFmYpiE7x7G1H41ZbYx0GbYb0J2qVcE1TLSS3gElewYymfyqggHs/e5KKt/cCOpk09lX8p1qs+irH6eAGh0fs4xw50MBdgqQawW+WtxDjJJDlHhCSyVqURBFJnIUIE6SsoeUKwxTmGNAmSqLTzgfm/sDJ5MZFAbezL2UBY3Hn1SU0Fom/rTmR8KAsbfN1PnNwbM7djfrkgNx0y8bepPOi/bZ3wGhdt1TIBpDzKPxz96niZjkxKqUzWgPRkBYpd3DDjZtqn/3H0uyurZRFvK3lipsKr5s5SpGZ7BDq7TQfwTtct2rLvmD0VZvZXSZ4SZClA1l2SzZZKNuA7PHuHe+u78elFWX4YDpAMJvsbs2G48RVm9c0A/7/W7jV35tq//SzuRmOzAFZBKCN+ROXKPo5+gSdvUv6UHxSCunUih27v/dR87jhEVUwYB0EFzmiuRux07gLapf0WHSb24j9mJZ6B+2b8d3DEuRQZzklPIcSiYSUGskrap3xf/R0PtOylATfDARMfSD4qy+iAMS1KSd8CWzmozbRJ2sAnfu7nsyxv9qQ8r6kXRGCs5wcDMVCdQ1ElnzBRZau2lOE+EJzYwOcy7kkezmczOjdi4snPhBpxdvyIwmZXeXjU+WM7uq/ccrU3MvXp7OsxQnOPR1dwDcQ2DXwKgdt8a3vjC9jjFt3LU3IBS+0/MThuj2o1UWxKxfOVsYOJElG3ZEKAG4A1M3n7DV+diaT1WdRRWce/f7ti4vQw7pt1S7ef2mEE7hjFrUOFbR92U2nsqrtQ8OJt46vA+9o0HKHhrgmNJ7i9JljN58jXsXKo3NOwatR2sHI+ndib8+jXbTXSYOEYPUPubcng451nBNG+KbDIHsqatYAYS36HJR4CpmIJq7tVBqLraVGNmHuyM5nBADEYmgLIJeA5C2Uye1MZZ2qqTJeotEW//irdxDw7ix4DJjTI71+IeBJIP2uMTZzBjAbuJd0yHbSaOd5Ow9xNzQlFgp8aZCCiK/S322kcsImBGemB6J0uM+UpL0H56Dm80K6c4IO8IjccEcwo4SS/o589qYurFL+xj77USApMf2mR7OdUBmePJHWbmMLG1M8EgQLPJ4G88IWsDgbM+vDcl8MEjQxW4eG0yoKlrc3UfDjgXa2ZmjgLSBqlMhgekGgP2pcan+sKHyCYFgUxW9znW5nhIIRBz1W/IFK5jBh/7Cw5oCChfG+vLe4CjbOahzMR7eTJZ5Dve60UHajIxZqqxDM3L6yu179nBxPszUfPf+B4FptXeb6qdMBLIWH9efS9gchuZ024KU9T37QF9p/SZ0t8oIO9rDygbuCbGwtETSpRDH15UvgPCi6r1uww85AAAAABJRU5ErkJggg=="/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.9802"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="8" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{7e05b403-a382-41e1-bd57-e0a50c0eb7f8}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="station" filter="&quot;fclass&quot; IN ('railway_station')" key="{2341013b-ceb7-4b27-a640-f633e8ed1488}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="9.7895833333333329" shapeSizeY="10.31875" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="1.05405"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAEoAAABOCAYAAACHQYBnAAAHk0lEQVR4nO1czY4jNRC2O5mfFQ+BlAkSCiduvAqPwAEkJLRw44Q4IHFAnJCQ4MABCYm34MqJFhK9feTM3+7OXzqoB1f05ZuyXe5MNmk2JZXi6fbY5c9V1dVul73bLXn34ml1yAPxW1zbBTDWa2baVnCvtFMKUIkMqcHmwFltA9h0wP94pczXtOva/29LKXAsgJhBKxXaw68GjnY/pW1DQFsZtYbLXK9Iw/yWAFV0ryoEbluyANPRvW4IYBahPfxyWcDRysxaG7sCCLmLlGNtbOWjPAxMA6aC8oS0i7WOtXIoaQMWbRFAlqH/LrBXgPMWjcoBxQOrCKAelGo2X/zp9kxtU79KAK2CfEsASoAUkAREnDgVMD8ApImUZ/PF3+7AqG3qGYCyhF9kAQrLMcefBIpNpSKQei36yx0otU39OgFzGxivIZjsvxyDJX5EI3bGlfweMkg9zeaLX51z5865U+CTwNPA7EaS/jPlozS/VAWtStKT335xu6aL197IVTkPst7AGHqtEmLtqYJ2eavpaVo0EZ7NF3/sE6ASwNqmfisA1fM1lIXZHGMhRNT0OIj0OW3aB0iGfnutOiPzm4ZxyC+boKpAGlBc2efMbl8gGfp/FJjBOgErwRjQxcBiHxV7f6uAx0Tn4HOEOWSoKJ5CH7Uua85c0yQPM5CdTYOj3Yq0PvtrSr89UA58D4YEUwKtIr+04dRjTz220QrAGhOdU3C5JJAmwaHLE0/o3pPPYnrViE3vVAHpNoxbAELm15mk6UkF9lGTEQJ1FgZ/G8IBCTbxiSfvgzzmaGSuLbDxssjEjYswGsfQADm3BOSHhAfejc/0BCQEB8djCg9ypqSZ4JgIA0vUpqL3PKcM3Buc+5iII3DUJgQpO/7c6oH7H2hUBSCxqbFGuZgypHwUlr0bJzEgDJJQ1IljQxrFXmW8GxcxSJqVaGMzvRTHKvsRAsV+SAMk5Zc3GsqRd+OlmOb40nGWOGc/ctDcNu5kbE+xIWTRpp1s0sjSvhfydkEvg0Y9CB2BMtIRKCMdgTLSESgjHYEy0hEoIx2BMtIRKCMdgTLSESgjHYF6UUBd7HifwaHI8TJo1Kp0T/k2QPlD1ipD/7mvwVlKfVwoWuS62BNYBSBtRbzQjh8Jp/A5+jxwv3vtldl88dOhb3Ztm/oL59yzwP8Efkrl/t7zwNeBZas17qdaWTMXzLOzi41lh7BimtvNImUvnNKmXe2+09ooBC/3WUr73rdBmDYWa9wDSD/HJNn1FsVSsGbzxXuGT1OmfQeWTRrr67P/sgHcPp17aZuz+eLDwu98UVCxAm9qFUd+Opsvfk8JxDNrcLQ/UrLOEuOc2Xzx9gP39wE5c/l9Hhz6pXPuCjbt39ukr2kU716pHljoH2CroGQUCPfCXrVN/U2qDe7D4K9454rmdpLhUMxHmZ50TwqfRm1Tf68AJDMpsypgfVXSdkYWBkPbk8B1N/4/plEustFqsPNum/o7UG0E6RJimQ0OsdBDPwkZoNSWy3XdXCX1/pNykL4FTRJwogARWJ89EFia4zZv4kDTS8VRSQEzIH0dfNKGH1LAehacLPJd5Nw29Sex9ktkIYq5G/UJGNtxl3VwF0Egg2BsalcEjvymuK8TJYMsmNIv49IoGiak4qjsW/ZF/gn3JQF1qWjSUwu3Tf041VdGFi2dnym5Z8qSrzeI2qb+XHHY8hvTHM301tw29fvDpFknBw0+myW3HnXXaNvUi5JG26b+lEzN6pMQHPVe29TvFsrymLKoOLV/Y6ylQN07x6Rt6jeNgn1MmsTgpDQpVUbNescoy0cQaUtarHayRhYsn3h9mYYUiTNaj3qklDG7EvNLZBYxEpcAU1iuyysDksgjOS2YdX4G17FfDwmM8rTNhSQS7Gq5xneA8npU7GScjtK5ZHFLMsCFJAdOhEWgrhNA3WaAuglgSL9S/5QypxAozKrCQJf740NuVK2KLdyhanYE0g0Iz9rDwiKw/F5XApTk1/GJGLeRswxQm2+Uvhio9Upm7DQNBIqRlH/slKRAPEtA6kjOCT4pEVztJVgEv1FmF5emTxSQsG3MnsLxdEo6/7XSJ46VFWYDqBUMEA94EVPqyIQwEMUcXZxR1CgEhH0TznAMKExv1bI5ESgeB69UaH5IxoDWtAFWykdhVveSUktZGPRNksSMJos+DWc05S8YKD5PhTWc8/DYRzJYbIIos2p6rE18SNUyNIgvjHwfZxPv8+yjZrFjZgGlLdRq6e+EgBI/hise2kTj5MQmSX2gsemxJonAS8XcpA6fSMFCivqjZmkgdRGNkqRoZhmgdiqGNpkoA08UtsdA3TM9BotNyysmKmbBiYIYzC0LjihijRJfiWcSMFiSko+mz0CxuYrfzIUIyXMPsAM2ASHpHE0Ol2xS4QVz6qmDAGlugXOEebJcYsK08CD60oymJ8Qm2PE/JZy4VicGFgvHL60yOQyW1iYDhYRApWTRTG79tyXgZFqRYCKottKg+RZ8OUUTZUFFM/DQBs0t5A6wwD5iciS1KRYeOEV1nVKP4y0UkgcjM6oJK32wgNKHaKvWh5ifyKEtD3EfMQ3TtGlN/wIOS6dqZutMLAAAAABJRU5ErkJggg=="/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="9.78958"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="7" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{02179e8e-56c0-490d-8eaa-6d6a37a41076}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="marina" filter="&quot;fclass&quot; IN ('ferry_terminal', 'slipway', 'marina')" key="{df15bb55-361b-4fd4-ba66-d4924d5fa45f}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="9.6572916666666675" shapeSizeY="10.583333333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="1.09589"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAEkAAABQCAYAAABVqliPAAAIyUlEQVR4nNWcPY8kNRCG7fm6WfgNJK3WBc1/ICYmIEYiOImE4EIEGREiPAkhTiKB4AIICZFIECEBI4FG8xuAE3t7+9GNerFH775XVXZ7enaakiz39EyP7WfL5bKrZr2bhvjE+52bcOfuo73cPnSngndfkLzQXmnbnXB9VFiLe4bjM99zhSC6/xMkDzWDwXspUJ1RIxCvaNgkIXmjThVLuowifUc3NUgeag3ODGoHr/k5J2hMX7fhuoXXCIqfZQ2bjCZ5uJ4ZNd/j5yVAsY6DjzVDw+9wU4HkaYAMYN7XVd38PeRLd9vNGwCrpXJDmsJAUSu7U7sAPtRxCqGm3Jaqbp4f0sBuu6kClJZqvoclgmkPBTUWJE92Z69BhwKKsttuHgKQa6qxoNaxcS8e4CHiDcM8GqAou+3mzQDiikBdESjNsHdTWd1mwQb1xZR3v/7tzutn7/UMTFkHIFFb+2tN2GYVy+JIU21mQWI4fN+AtQ59vhQWC3Y0RzPg0diWiKdrLKomaYAyP3PmnHsAZeWcWwZwC2hXc1T9VDRprmlSanrh+/21oFFrWhgkzWlD2+iJ+1Nokle86lmuTZKmVIZNOiNtWoXCmoQgpb7emyZ5YYohoGNsns/gD4url+YvzcfQppKBeGNvhqCOBcmRH4SOJZY5GO5YirYshxhuJ8BBQIuhxjnDqD8IdmktTDc24NifomkWZehf2wuOI4OKHV1INoeNsyaKfVqTgY7O5FLxwFmbZrBNydamEk3yUONqhvZoHjqeO/jcz6xIg7AsQ8E+YL/4tGHwgEu1aBG2H4N295Ym5UBk2W03bzvnXjjnzkP9MpTL4JVfgaalzqGKNclDLXnXp5ZojyxtstwCU4YM0At1tEWnliX5S+w3sfEeNO1KXYDZxDRpBQb8GoqkSXgM7MaC5A3PVYSUsz/TJOdZwW5J+zcsNzTV4hhQVNs0VAv8RG0S2iMJmGWT3DENt58YJM0eaYCObri9EB46pWjTjH2k1JQ7yinAbCKQJEDW8u/GNNzemGr4mSKHcCxnUvD8rX2bH7rpLd2W+IlpEkNBrTnIaMcvHyKerot31keQ2BcOoWtaf5TVzdOXTwkQi9THo3rcPtV4iIf1xxivwRHr6+H1vlR184kbKLvt5nuIrV2FTWu/eb0Im9m+pPKYrDFEu1SkSYOXSpJWOPspEQw2ck6A9LokCOmP5Sd5Yc7jQBhQKSSO/3PSBAPjvkjj0DTLl2qSFxxIbZXg8A6fO5cIg5YSJxhUlzEWf6hNsvwKn6lNPD3GgCSBl7JJJC2yfD7uf1KTUjBmib1QbIinxSE2ydIeBJMzDqnfpmvAmsQPeQWO5u4zdLZPJdJmFinZ1Cl9xbMljsth31+BxB+6k0bj/kvG+jN3ZLvt5h0aaGl2xx0YVd08zmz/LWGrEqMnCIa3KFH2r/kvL6pmVTfPq7r5a8jIqrr5biSHc68lVd18OKD9n6q6+SVxOoCvVYM+y5xmRVLVzTcj7e96QB8UPmude0t7vFd4SJ3neTsvH9stqKdDllvlOx4d0AUGZCVXiEwkmyQZ6+RRh3XEUdXNE1coVd28b72fkfi1NDJ0MamipQjv3iYtlO0HG7usOH7hWVCxSCFzoQ99JEXKQkEjHgMFHQESpxsDm0mapME4JEoyVAa0hSFwDhZIR7ym4XaGT5Qt9wFqYBucKyDZJM259AfZpGeUISINYuzpl4KjtLcS9pLXmVlxe5ukSdIFeGaAGhNWYcASIXGSvBRNwRUOxVsb3D2k3XbzsKqbP7TOpQaRuwpqz6Qk8Z2Yu2TlVTrNA+cNXyQbI6KrUNZV3fw+1qDGlBT03XbzCE4wpcJpOlHb9ntChoRJoQtImlr3dVU3v6Y6fV+wcjRyt908JiDnUJ/DMTBDumZICGpGHuoKIYVz6p9zBnEsWLnTdbfdfAzn4BFKhPVPqC9KIYnTzQVI/SF/VTc/5g5qLFhDjP9uu/k0DBw1iLXoHABdBEjXQyDNCdIDjoZUdfNDyWBzoZWuiLvt5rMw4KgpEhy2SRcQjRFtEi7zuENGbVoHUDFctA8bVXXzrZuA7LabJwGOFHI6V+o43eJzDOnWv0olqy8p4/VMKb2t+uJEcL6EuJwGSbJLuLK9pARUExJuatF4rwBSTDZnULf3qrr5/J7gfAU/ELwBQAwJjfcL0iDUokslunMLySm+UrRLC8GAMyys7+RZV3Xz0UhQniqxvGtBk6JBRiioPfEepzFHg30nIMo7fidMuYWy0q2VwsnoVnoetqsdzLWJCIykSRFULKw9uKJdGVPttk3clvDv7D2cs9zAprD/MnZC4/PSRnIlnAhqiVUSJCmGh3sxSZNQm9gwMxCG4riOkKTDpvjQDUDB37x6ZSDY+VV4xjpfxo2lFtbh0BQOECFJxvvScBg5jieBeuUUgDvlQaO0MxcpUhs7cUnTbSEcclnJVVY0WIOEmSdYszbhj3W4nTsiQfJ03usJlDYI7PQydGSZmRGrHVNIWqQZbpxyXPM9BKSFyPfANJuE0601Oq/ZIT4F1E4D4/l5DiRH/xxBgoSgGFrUbPys9H8EYpumJqG0mYC0JVnL0kdI2lSz2pISJ/CfKGhQGJCUYJG0SRKsTsn70SAtYCXUAEkJoLmQ4tTWQEn/gYI1J5WNYmpS7BR2uKV4lASQjTYDQgdVSrIYsrppBrwVQEhg0Fin0nVUSAzCgwHHgXQADwN9EQj/Sij1E4YcTdKmnQYtpTmtNc1SkCRQHcDSOh4P2aMTylOLw1TscVv9wAFJA7ZSBXOnlqhJWsekz3iK8EpnUXwtLfNaBkcKkvRH0dwDvidNV/xOFVAuJA2UdILAxy4uE06OTcqB5QTnUNOcLEBSp8aA5Qlc/IyV5mP1RbIZnTENJVNQBIcHPUS8UfuBr6WaRTOs2uCt11J9lN/gdhnvSSuWNa38wDYlrXAJYzwYTm7ncoRBpO5pbaY0SbsvDd66504BySnfp10f0n4KmHVdLP8CMFUPz8TW8qcAAAAASUVORK5CYII="/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="9.65729"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="6" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{383d6178-41e9-4200-a83b-f7730043c9f8}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="store" filter="&quot;fclass&quot; IN ('convenience', 'supermarket')" key="{3bd3d3b7-05ee-495c-a24e-37753ba32fc0}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="11.112500000000001" shapeSizeY="10.980208333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="0.988095"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFQAAABTCAYAAAABbiB5AAAIkUlEQVR4nO1cS5LrNBSVnU93swoqCQMCDBhQDKEKWAvFBlgFU4oHjx2wFMZ4gttjJnxGwMvrxFQa3dTN8bmS/AsdN7dKZcdKLPnk3I+uJGfuaUrW8Xe1u9KOj9l+lnjNAjD12mQAzRLOre+7FmDVCeeDy9xdTjLjqOutulSpDdAycq2+VkAz43iUnNSFANdiAVQTYA8tzcaTBTQzAGUF6/A3TGoDTPwsDE0xD08S0EwdLSCFnTm5ZgGLYgF5UJ8P5NpowGYXAjMH0FKO7M/QwpgoAKYcNdjMTPR6+KEkIyBoJupyrJutNttf+zRYlcWbAJAGTsqeXGPMdREGJwEwlGT+qNVWs+5UVpvtH24EqcpiowDUYMpRX0fwtblwXUEdClDGygyAnHkwf3MjSlUWWwDwQZ1rUBFcNAedQM0uBeZqJFZaUpXFuwDoA5zvxwB1KEDRe+eKlUcwf0+92f3PPwXr12+9k9yxqize9+C99uC9bgFsLCIYBdBBwLyPgNgH3KosPvDA7RS4GthBQRUH0kUwRswB1FHBTP3tarP90Tl365y7c87dOOeWvix8HD4X+w7PwJ5x9MAePXuu2DkfC0h2nwhb73yf2OhMRNvMvX8OGbLWY6u8peoz+cdD8WVXO9nHvlZl8alz7pVX/VfqfKfMgLarnVR/CEDPbKZzbh4KjSxQ2jibrvepyuIzBebfBqjMpiYD2sWGZgnOaFQwe7D41pelsqdiS4UQOJoLmYlRbKgGdRYCdAgg2e9b2ONbMq5nRerk2Ub18kF2rjbbX8Z0QilitbXabH/woFrefp7A0kEZaqXjgup+Tx4wxs6qLL7W7a022y+s7x7vhW0cPxtt3MA4H8uMeHlhaZSxbRjK0nGNQN4lSAKYL5AtVVl82+eeSjQ7haGLBFuKudpeDA05IunArK9N9kDKfVFqAXW12X7eo5klGd9LmYOHxzyrFbsmM5TZD8xr6vhz3tN24ohFd7z1MNBoexlhqGVL9R9t2tW8Z+ZdM3OewlBLNauyeAn3F2l45aosvmlzb5AFgBkDVYDFhDn6kxNAbcFkai5l4TpIVRbfQ19Q1RpJY++0ugiCmcJUBNYEdd4CTMtmyvmihw3VbTEw9ZRF38TOwttLAW/pR0hyXerE4zMzo6dPzlR+3sGjIzO12iw7qqGAg/M6LOCW/lFJaE8DuoQ8KRty6n5hH3Osw44xB5T5gP1P94ykKov31FjfSp7I5N+pzFvkN5+bLI3IAs8PIZVn80PPFdCbBDAbM6UxG/rcGXoILO/RdScizluMhv6zZMclhDgzzVAN4syYHd1rQLVzYqAmp+QmJAJoKL0n5eTItSq3yiL1zWU+JQlkpTDolzAREyinYD/klP738q6R2luQFJ+k+R5xi41snrOXX5KM1D7AzkdQMRmB6v7cvfyCzN8zQE8llBw5A7cqi7enaEfX5BmqsvgSkiVW8rlBxlByRM4xwzLoQ9wHwq+U76Xeq6VYrGSqnrdN37nUCaoJCYJoTdw1JJV15g2uWe3Xdt81iLKEJzQDGmUolaosPnQTl6osviLOmGbnGckwnzf4NhMm2tb1YfhI9tOKfJg08qWY2MVzfa3XYv4rlzoVizyCOCYHjlO5H03Bjq55uKQn/0LZJZZ9eix0/pt8kX2eotTGWntWHJkmOQPUonVssmxKckhcTGYuc7RUXs4tYN01q/3a7iuCGNrbRLXXckr6i3iz45z4J25iUpXFdwTMxrNHNo01Fhfo85DaH288NdknlNAukaBTCgE5CKD3PWPREWJQa3ljyg48E1Cm7o7ZFb9e3XzIKwuXXiYyNLqXKabyzvBucvOpyMFgKO4TDXl6ZzE0pPrY4FTkQHYtx1hKY1OWDw3Fn3XMjq7J8mxLYt8L1XexmwGThIwM7WDWuDSmk2NDTzmn8dkUwqfq33AppOaxncsippc/+wL8C0wtrl32hu1MYWl0pBRKjEzVMe3JWvvYTmUzUWIx1AJVWHoqfg/lkw+f1jxcehEA0WKplSihNvRUQUDFoHYKav+QwExkKHp5p4/WQofaZ6mtIai2J8fG3TWwlIh+IYF+KQG++YEBmcxQLTH7KQ1eq7w2ihVChYL6R0nx8vozC4AfqrL42F3nZNwOlnzjNm8EU7NUJOrlnfEDpvZaRa5N8CUEGkwGakjdnZyHFi/gqhHZ+SFLU258kfd53PnyhjrK/nTZARx6z8eQiylYuIcEkJcQSDluyvhLHaXIiwpekZcUNHKisdV3Z/Yh0sG5Ap1tLzyo/ZQWoPJH9gVTg2r1d6fACr3dgb0yA/+4k4QAFU+vgcxIyKQ7OfMd04sEdPwqgLKdaUMv9dHMQUcqgCKYyMJQtqmh7jFANaiWCukOzggzGZhS8gszVDREirBRv4Oky/tHkhmKHXTGiOnBg7kjWwz1g8j2P7bT141kQx0J9zD21M5Jqz0ylAGJJrHV3kyt9ns4IstqAF62Ae5gRZteJjn0ol4929AYMpNwKfSGHBwlNoAUSXVKYjv1ZlJpJPMNZ/C7OuC4mLoHF2EliqVNjKXI1B0cUd2R9bqNZECZLRWWCkMRgJrEqhpMczk1uVcXsRI7zPbjUFO/H495eM1OytI2NlSzVCdWpU4EbSwLp0KADiUWoNqup6buBNQgO7vYUAE1tzLWjjMhtHgVbedQDBU5JCTKcdxuqbsGk0oblcfPyFKsmxEwWdx5CYbqfrGchDVJF0ood1Z5JsJS/MdqqNPDVrYBYkjbicLCGxwqagYigDjVYRHoTNo+BHMgbEdE7o8xIK32h/DyeD0GLILXGKfH2Nm14xaojgDK6sZmZgpTNeOYjcW6JDD7AMqOueG129rLoZ0S1lnAsqhA3y8YLvXtPAbhFmBZ4A/AtseyofiZHS0WIiODYA7xENZOicw4WtcuIYxhIfYhsEnyDyP9TsluUwXpAAAAAElFTkSuQmCC"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="11.1125"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="5" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{1df3a234-5d3d-4b7d-a95b-4177d0ce9e39}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="spray" filter="&quot;fclass&quot; IN ('car_wash')" key="{0c711049-d428-40cb-a7e9-474d6fa3425e}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="9.1281250000000007" shapeSizeY="11.641666666666667" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="1.27536"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAEUAAABYCAYAAACjxTpsAAAHaklEQVR4nO2cy47jRBSGq5z0ZXgHNiGzIKxY8SKIJe/BFvEALFnyAPM6eIPxBgmExAYhpqc76RRKq87o959zqspOnLglH6lUzsV21Zdzc/k43r0+8fQ6jH2CqYgfMFYLTnjtUDz1vF0qoWDblKW7vnja9hlQKfMp1YowZSgeeg1OCohXgGiA+H2UMCUoHnqcaKV8xnA0c9IABKXh+U0NuwYUDz1uH4AgGO093B8lBeLQ9vAd2TaPc2ko3vjlBUBJL/t1JmJAkG3RjJRJCajgJ6AdHvvVevNvnwO3Tf2pohnPAISbBq0DamwoXulZOz621Xrzz5CTtE29pglje46N32M4YWzz8UbP/gLb4oTz3RMQBPGsNAdmJa9Fzm4+PtGL01zA6wX0y9V68+c5B9M29ds46R31rD2iOeFcUDxt82uOIALiBcZqvfk7dfDffv2l8/qzt1/0Glzb1J9HGFuCs7PAyICHileiB2uBbL9oA/Q3fYFY7xWY1q1z7i72S2gyxs74lyMmXxWdDE1F2iXkLp73KZGbYHjeD4HiEz7DjCzsP87h5AtN657GJsIhWd7rrSle6bXky4KBQJa5iR4maU3cMi0FzBvwazJxDMfY9zYfr/QdE1mtN//1OJ46KX7d17Ea5uMozd8ruUslwEqh+IxmSJidolg5DLaO6feJPj4BRMziYqJpkKFVEnluYsPIgxGyV/TxhgOViHKxaML+ptC0bqM23MbcRAPSmeMp5rNQnKc5CZyMJexY8bsn+JubmLgtCoC8SA6KN/KORd+r2VI5g2Nl4URNSx06YKoBzrW6YOJ1krRN/V0iZdDyrWJNcUZCNjlpm/qnmLk+Ouce4ttH5pGTqtC5euU65qLCZpUxM21B21qy5O8nNcXHXstOi5zqkNS8beqf44LTtwP8jZaPaAtP1tKlucjkE+n8JTRleYJ5aokZr6HwWsqR1iwHaMli5ETtEEKHyhbaTmkWmM51UJUJwZqWnOUKNyEvmtg29bs+O7VN/WN0stK20CMoS1s+ak3Op1SsJav15nc3oqzWm69hou/I9rVrl6c4WQTyGJsFCeHwcqRqu97yJav15g93QYmABAj7CZn8of8Q2yP1so1gNFPqOOMqA8OLlqzWm78uCQTAfAOD3xoaIRAeAIYAQa2R/bU12n2Jo60oC7ym7GEi8ms/KYA+xO0H0hbUql3OvzAUb6zGmyF4wEKyuX8iDxGTQafJmvJkmBBriuZTOqGZzccZS4rVGEB6HA9vTSAQnPwDNHnN0DS/chR9MOzmUvxRgWSOy0DYycq1DvoVzdlajhbBdPKNlOlUblo+hR2tZi5aSGZ/UpzReqVde6kAQ/EuEX3Q2VpAtGy2A0egpK51qgksSiOUbcKUsN9mNMS6QHwxH56wV3KWKZjPcyIKMRx8/zkBRC3eSYVkP6FFJSzGScFBGHxRyE5VK9g5WjrIRaBrCt684iUBNA2raVFGW3TKrryJTAFK7qIQnbAWbouBHIQdbWrB+pqiVTtacFILSexHNJ9irot46q8t2vKhVuTHdW3JKKMBKUnepmI+lsak4FiFfqp2oOTMwk8ECE/EWnS2oCXNhcVaZHKG1lxbrNsUOW0ogiFS4kC9m5Zok7OADAJTGlW8m67wxF0f/6HJtUPtJGWGosgMRZEZiiIzFEVmKIrMUBSZoSgyQ1FkhqLIDEWRGYoiMxRFZiivHErou6w4JpQw1sl7SMmqWrgElOCmI0e3NhMgwhhQgjGAsZ+2SB0XV+21RWj1nvBYmhJSqnluMJnyLr7fI2NS/6/gFMH7PtqCb8gdYCyNIbFufyIcZ4z/LGu0gQ4oA7im5G6JFt/96wMlZY/7w+u2qb90V5C2qb9P3DhnMCIn+RfLpwQ60cvJ26b+yl1Q2qb+QSn1tODIOE/2K1ptWwUPJdzEpzTvoX0S2xvopd0pf7SgPbsnwveDua5N6tmwHPQ99O+pwpqLdY7+BqQEClcdBBosDporiJZxEPj0poPvp57sTEHB2nss2XrKFAjn7hAWyzLuqA00GHUg+EvKpGV//K48BoNPuFtQAkxOJosguOIxZUaWVhQDEk0RMIGAyGA1LRFzk0nid/GhaHyw2ylQHD1JoRUSMxjr+Z2zRCKraCeQpshg5aHnw8AcmQwDYS2xSk/5B7AKidmUsC42V/F4UvKWMp9dnNhW+bXx1xJNUv9HoMBUNYcr2sE19lgQqJnPIEBsPiknW8UB8K9tmY35XwK0b8qHcVmoVhKac7ZynsGa4mmAMgmB4hJasstoiUtAcRlt4UrrXFn5SRFIC8le+fUEjIsD0UI1/sEC+xKXgOqU5Auvdfgft6z62LOl+jkoe5jIM32PVX0BfoefKktVW7KmaBrDcKzroP25oSAQb1wMak4MoWjRxqq65EFb6QCC0Wpn+eqZgZxsPppaVzBA/HwPn6MzRiBsMjlNkXNqWsMA8H2GebaQjAPz8FpOVinXEQGgMJCclvA58Xw8yVQRsQVjMJycpnhFa8ScGFgKSKn55MCket5/sPwP0ACjvMOXyb8AAAAASUVORK5CYII="/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="9.12813"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="4" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{597c8af3-e801-46be-adc5-71247550dfd1}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="golf" filter="&quot;fclass&quot; IN ('golf_course')" key="{af0741d4-1a73-42ab-8836-154a76fabd6a}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.847916666666666" shapeSizeY="10.980208333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="1.0122"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFIAAABTCAYAAAAMcFA+AAAJQklEQVR4nN2cv44jRRDGu23vn7uXQDI+CQxCgkfhTQgQASEkZARIpAQEXMID8AyIjBESsyORIiEQ6Ni727UHeTVlPn/+qqdtz4ztLanVY6//9Pxc1VVdXb0xnLbExN/qcCYDPeY44g7vrU8B8rFBRqffV2oHZO9gJ2F4iXSttJFf40ntXMehtTWeiAZGApijqax9DNUav957z9mAjNArgAqm0lgWhuY9DqL3njtZ047Q2/UIHo/EcwouioKzbK6XDlgFV0l9qhoZHYjcj8Xz+H6UugWiPccgPbCp/iQ0MnoQp7P57a4fVpXFG80lA1lm9KEFLo7Zm1/dm+xTYtOz6Y4akC8O+fCqLJ4JWNhSz3lTAV4HR3PdG+1LIrUHgADyn66+qCqLtwHWAkAtBEwFGjXbm2ftWt5onxIdiKu5cDydzf/q40ursniHANq1ei6lrdmOKh5BG8dNm0xn8z/wDTe//rz1IW8+WzHZX6qyeLeBZm2ZuG6DGpw5dTCQIwK5cnIX09n89zaQHUM1TW1rNcFthTkZOH4cgUau2k6CoPeBOp3N1x9QlcU8hHDfNAN434xx2Yx39VxIOKK1dx8q/FEaujPIjqEW5P0XzbgMLsoCxm3OKAylkRF6z8w7kUOhhhCuQwh3GaspA1pz3xfIKB7ziuUgjewY6pXzA6s5cSlgDm7aoQ+N7ADqNfzIKDg3GkBrG157SGeztbIJA0oL1CvKYfKKyCzI/sam35tp55r3YNKikSuQQYQ7HF9yms+0Mg6ZIY9wrcyoF8mcJy8pOF9AiGbefHRKph1FDrJz2cNzX0AcOWn6sQNQevVjOJtIfSdy4KpnAisu00SbFxmk+wFDSoQ+HhNgVRYfhxBehhBuSfM4qvC2QEx6jSNZ+IsPAnmI9lVl8XkI4ZWzfFXQePwog8aRKPFI2vdVM++9ztxmyN1yGCxp4Um2Rh4A75sG3l0iXZZKny0TabOt62OB7E2qsvgWEg+q3VHWhzNABhdTaa0Z8kcBsiqL5wTCYN2BSd81Pbc7aAxVbUPIxO7kEQCsKZ+oAFp73Tga7PE1rL3K7OVWw9mBrMriu+ayFhBRExVEbK+a8EdBZa20rLln4oOFP12KZa3RYbAWoilzzzCteabODknuh58ryJogIkA1B6rr1HPK+bAX35BzBHlPJs3zH2pXCi6+Dx+zo/I08iTiyEME5y27cXQg3Dwz98Bh451FN1g/R5D3pI0G6yU4EOxfHwAP48ik5z5HkIuESb+kxmZu8NBseTuWKzM4fkQ5e9O+JygeTDZvnvtUmJOquAhDa2SE3suodA2S50iMEXFuVOaLmofLw5ADsS+Q0XmczDDvIKg9CFMF3irQxrkwpX3ZBVRdg4xOfk89d8guIoY+2FhDPeei4kOul+Rr67102sEgOWEbElUVXOa8r0ZyGmzf5kFkU8Y+dA0ylUEeCYi4kdRVgQDeeFvLMVnsUbJgTg7cLuDHUWjjONH2lRQAN0TZU7a2Xg8Bmdr4GdHfIu3CrQtLRdtXPMel9l5S26lWXYZVZhG01yBiFYaUSQcAR44zQYgXVlxKbR/xgOD0wZrPdY2BIGGpnoHFgimWncIfBVH90iPqURsf9omns/lvoSOZzuafeH+ryuJD0nhzKnhPqIlY92ixZACI+COgVm6Z+2QHiKx56pDRmMuZh5TpbP49P1eVxQcwVis/wbIUu0a4qKlKO7dgtmkkQ2StWx3x+DOcsExn85/wcVUWb7WERFFAw3lUzpcKJE/gnub1crSjb5nO5r/AuRxeb7PGBqonZ5hroHGHk1oPWjidzf8+9GZuWk4v5MqhpxzgpINKZHgJDQ7eV1IrkN7KZLwPxJuOoPUJtyqL98Tmmdrzdvdu1BJPeeNx7nG3m4HBdQW2Kov3nfW5SnTgSmmp5khe8mFMdlYAeVwZQJ9QGV8gx1KnTjekQGadQDhVgHsAvXaCbzZjtRKqRy2JCFwpuIM7J0mM+bppV00p9CWsyLD4VGlsxHWyiedscgd08uKM3SBeEUQDyenAjWUzmrZaBiLMxy5XtN2wgNpyryB/zSw1R7aa9iMFuXBON+AJB84/bMyRLEmN7CIYPpY4Yzdz5nlRzY9bTknR9dJUuQM6aUmMGedEBtmW10xmf9Rc4A7s5sSdT8aPrjL4noPZYpKTpY67DPTmxIDuYDVqb2nLqXhvViaMWwMWT60m4ms8gf/I1tqfhhD+bdoLuLZ2K0pgNtbgXqhj88QFxFWrJdST6Wz+4yPL/nzWgDJgCPJF85w1rNzYKI/OAbnWSIMZQng6nc1/CGcsVVl8CaUtBlK1W6GR2SDHAuQVgHyA2QB9Hs5IqrL4mgqvDKSCidqoCrLWqbVUkgJBXsISagtm+P/xah79IpyQNAeXMMDGglOsXmOYDNGKshTIOgXStlE9rTRTfwrXtvC/hLb6R0kfDQgtiOJQPj6ChVYI8iU5F08bsYZIggxiO9VgGkjUTAZ4Da+zHwCDXFUL1BZi8GOvkoJLUbhsBRO0BkTVVCJErPw1J8PauOA4ErcY1YCw4mvcDIbTSgFeewkHyRmkt1ow8a5T5Sk8Zls3K5Bc/sdFqVjdyyWAsnbIQPIGuPpVDeRY/I+cAO9BM5okcno4lYTcwJdEldyxWS9bDjWpIn72zKn9mpDSSHuMA+G9HL6hJfzydxkJAG/9GjJhetrI+ympOkrvVETqFJgs++MlIsLEzXLbo4ji310F0kSs7fH+xQEnjEcdmbZX6ocQFcy2g0vextd6DCmQBhFvCM0YB7+g0wacXVZZZg9kjlYqmCmQODVxDbp3dlGdlsVaIhckmzbXvVjlAb5eOaNJMwgF0ZwMOpu+QJqVoNNRMBmot6+NcyNeP3y3yv6w98bdMoaIkCeUUea5kb01F2UhvF1MGx/zzbL35rkSrait0oIdzcZYckzbq3fBwY6d1Dz/2xflsVVSeRfZCkUcz41lJ8oBtdWZc7lKco7kXxxNfZEY9NIBuVHyIlZQqYA812unAnIvplQwEfQyQxPd8CcFtKZNcfsQg1RTfaGngW1zY5caqeZKT0NT8JQmIpv14D3hG8QbZ80aCVApU1aB+K7BOIJUQJVzUN5cgWaHoiBuwGwbtILJabfY0mOYY9u6OZq4S0CuQCIArHX0tE31ypzVd4f/AHOHydWA0zyYAAAAAElFTkSuQmCC"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.8479"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="3" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{c676aab6-7221-49e6-aaf3-4f3a26a9aa04}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="barber" filter="&quot;fclass&quot; IN ('hairdresser')" key="{49bb9e6d-96c1-4235-bd46-8efab78ac763}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.980208333333334" shapeSizeY="10.583333333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="0.963855"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFMAAABQCAYAAABlJkmuAAAKUUlEQVR4nM1cPcssWRE+3TP37nv1JxiIPa1Im2gqCoKJgeB6E0EwEAwEA8FEzFcx2AWFi6xsoAYrmIisZgYGCmYa2Qr224KIIoIofuze985MywxdL888U3W++uNacOienp5T5zxdH+dUVU/hlqci8rthAX6+PufipzJeqt8ik1/sZHP7tM6zaevmpcI48vfad7mTyu2zUL4b/l8ks4AjT1C7ZtEQcU37fWyfAzS+ZvFfTTI1EIuIz3gMqZ8FZsic8O8ZSDxnSR3WlkwLyHI8LwlIC1RnTJCvM08cR0yf3I7j90eD//A8JLNQwCs9R/6dNgkG1cfbMjHYhwCGx2I8lnRNfuvWApMnUhJom9N5VTf/DHXUd+07FDCPlmRWdfO3xD4ZRGzIryRAkW8UIDmEADKQ5Qjiv1I67Lv2XeMpq96FhFZ18+fEft+pgHiAo5xLY/WPBnQKmNhKAPE/mX2eJv5eQ5pONFR184cJfVcE4KntCVgGNdbcZKu5BmQBgE6hR4pKJk3IQzcA4J7s+57Miag7UpD/1MmjupejnfTS7e9/Y35X1c2vR0CvWlU3v8vpE+iFsT0c24NRmLbjuM82nhxkEuWCycugIgTmacIy6QCgv3TOvQ1bVTe/8vXL/Rv0iAB9oADKThTnOjuY1sK7tNTcmmQA0J8BkD+37rP6Nfq+GRuCqUmlBiQvuWZXc8sJXdDu3e9zmfT2EdBkMniiimtqjkBqW+AgpdoFXHTLADbjgB6cjlXd/EX7oSWJuWCn9td37Sedc3fOubecc0+hvTVefzo6omeKl3e0sljMZmLbpHYU6Twm/8ZwPqjim4gt76LeXKgIqYVPAlPA8d0bkHJ0OgwmA5lFc4B5YTP7rn2PdeME+xkkX999137BkEj24Ggzk2mudSbSCdD3u8RJx0hnjt3tu/bLI4gbj/fWcFhtnYnMtDhikdOhD9BMO+kybWPWPKaA6d3i9V37wbnsZ66d7Lv2qwAgrx9DQCVvYeewmWYgt+/aj04FdAKQr0TET7Ujn68O5kBB2PvIS9+1H1/CIQWAfGKApwWIOa45rA2mltUblCgPDjTZIU1Y6GsgagBq4b7sjGUOmFamb6DB3gde+6597Faivmtfg48cED54AsPaXLQ5zwamD8ijMfBz67v203Ooe0C9vwvj4aDv1Zg8kfYsQOfw5iFA93Lsu/azUwANAPk6jMscAx1DQC7uza2ndvRIgES3TxL6+RywAkD+wEiWaWDuA9Jpad/i3txn3A/KBPZV3bw696K9qptPKRqiPVANUC2ZFowQLeHNQ6nUA7aqbr5vdThlO3miqm4+Q0BaD9RnK7Wc02renK8frVbVzU+WjhpVdfM5I53L16zmm9uiRQjmzsfp6r8WWQ4xpM7acfXtpPMMYhilMimPIw4nJ8JU1c0XDZXVTJI23mzKAdMKFhTazTGZxRwKAPoVuhQLUkwx2GJpC/5cYKvq5rdWB7EBjNwIfVU3LxkFZVog2Afc4qlebVAllcncugzSwMsNiFR184pSmaeO1/guKVOZAqb2BHmQG2gm5QQwJkToN0rj1AVH331znQQmPx1+qleDqjwFVlPsZE6fVd08gfw4txhgrYLdZDB9UshAbkcg/5gz6al78wCgr1FmUtrDALAWoIhNFJgWkIUB5Laqmz/lTHauqFEA0O9RRQfm0OWcC7m0+iMT0GIOIKu6+WsIhOdd0YHUd+0nnHNvjg0rPJ6N1R1Y1YFbT++W0wemF8iqbv6xxsSX7rfv2g9BiQw2KZWJAfQMZvm8gAxR37Vv9F37Y5dBKTyruvnFWB3H6n9fPxWh8oUGJtuCYikgd/745I/kiZ9AzekjA1Cp32RAtYJYzW4WRYRUSgfbWCBvAxMJAPlDzcBXdfPiEvyI94fBhloqv4cI1IXKa1EjbbcggLoV14/D1MCDNrYAsDcR49lQ3fv9A0eAVNGF7eHfYwYbQ4ElzGMlFvp4Jd4/VUq1eaFvrTu9NhMX5uXcEnnr/x2nH9bkfeOpfcd6pSsntE1wPtGD2pEqWfedrhtqF8zFpDg3q37JU66tBZQP4IQGbVspYOJFbVkUVRG8M+wRXo+UJp5INm/8LpL3TaAGYAPHi7Um20xnOJ/NUg7nVu+HJ7Mm74eB11u0SuNzs2ymEL9oNHn5sYu7j7OMa/Lm2nfNZqqvuGC5nQvsfNakY6qaz0gS+MCokhaeQw12mmSeLxqgrknDcwQTt5L3ETFS7wsQUc3Z+VzckOKAZiSvzVyYfECyvbzQbF9hfJJk3kY6hcj7kiRzZt6WWnMu6WpppHlzPJdjudRrKDu9Hy4UWJM3xmtxRaOpNx69FR1X26XYJ79TBpm4nOFSljV5a9lMue4863J10R5Np4Gnvh0RKWG8YF6Tt/OkJ4pFy2NyVW7n/x3vOtbknU0CZjDU1XftB+Ya3M4fz/y2UsL9tZV4f11JS0QXvfpsZlLV7C6w/06YtFYyfVyJN5dj82chrbpYXU9Kk22UhKQejf9McPrbh0Wo79pvjRFtaVKkKtV0Ly3I++UxW/nfsZ3+BeffcC7X31SymWcN0mwmi/bFk+q79iMLA3kH6daL4/hS6RK8vwEPDpuWmdTMwJlKT9EqNrZhH5t5Mk+UVKva+q790sy8v0kPDjXCetUFQb3Km/PGHf8qQiIoN/T3OPjvLt/JmMSrZBsx+c+FABgkxuDLKcn3ciZvAewZ/L2EFCaguotqY9ECJtqkHTmGeZHWpejJCwag+PmGQlicN7HWkSgRmA1EMEUKtAe+pQCF7K21EKL0JSAIMBagDKRkLnHM57mwN2fPLRFlmbhMUkB6qsT2jgASgilOjvM7KCFylGatNdFR7kfwhB+OcePhzWBqf4bCzlB7Q+MeNwRT8hrCTKRUeznqTgkAOLKveyV0hROSgckgNclk4+8U7ZF7RTL3ILWlhzcKB0unljdnG3pVK78lIOWcvRZ28kwZpCNpk/s2EZKpSWcqmNvxfusvySzJFN4IJjZUZwby6q02SzKdZ9IYtsffDoYp4H8h0IBHydSWJug5OTeFvDAWuYngjQ9OgNPA1N5qu1oaaTaTVf0wHvfKIp8HuAcbFjMhflAIqvVOI6860BFxwWqZ8CCl8XKMl0sY0VLV3NFgGdRDAMQDDApVjYsYUPLRkIfeukUp4Hy+AHhHFcCsQcwbbTaamDsFXJ9kDr69OTKUQXAKQQPkQA5As1lotzTptIDUJFMDNFTsz7wtM4PSqHnyISSZmqqjrdJCYZZd3ShpUSZ0bigp2haOAx0amGLPsYSl8PC2HmTMtpLHdeWAGEgNUA1MH5CbwIRYOjnCzvbSKXaTa6JYKmMfpKYZWtPCc+ejT835szB3hqoejcImTtZjfwwoLzk028RpaAQTr6XwtrSCz6/Wlji2mLd6xas7WMQjoBIsGWDHdNCqxOgBaQ9E+uDJasSAaWCm8Mb1IwOIY9I0xfnAxJtZ3QVQjNIP8J0cMRGl5U4QKJbQK+NOvxWniBIqfFG1Y3mHGjscfihn+h9KGzS3zHOnPwAAAABJRU5ErkJggg=="/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.9802"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="2" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{2727f235-0e70-47b9-8708-d3c15ff099ae}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="clothes" filter="&quot;fclass&quot; IN ('clothes', 'mall', 'department_store')" key="{5efcbad0-d96e-4c1e-933b-260622a31af6}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.980208333333334" shapeSizeY="9.921875" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="0.903614"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFMAAABLCAYAAAAMN7v2AAAIRUlEQVR4nN2bzY7kNBSF7apuephngE11tQQ1ggXiR0Jiy4oVLHgRNjwBa3YIibfgLVhPNpPJjg0wgIQEdFdXgjITF6dOn+vYSaqrqq9k5acrjv31sa997Xh3P+Yz/9ZMkH8sj9z8BxdiH3n7e3qnSwRonY+yMze9eeNo/T3FuMJjng3P8/3mmGB6OLISFUB/T8286bnHYAdD9fcA0VPiZ7gcqYqxFI/PqKNK+JwCvneYFsQZXIfzGFgux1BlWHk0kVTDb2rxTFZ5/IQgfQcPIVpHBVSZan45zkzBs44OrvFZLsdkfWYqxDncny2Wq9/7Mq7K4k2j4DvXi+Xq54S83oBnGeQGrvlesHpIf+pHglTKm3VpvliuXmTk30K4iqlisVxVmfkthAI3AFJdK8UmqdSPVCMC9J0iA8hfcypOEN7BCiyWq6cj8nob1BfAxc5ZtclN30+gxi1A96pJ/za04gThw7bAi+Xqp4nyexfAtelWnNcG2CSVpkzz0Fmo5hxAzhfL1S8pFXv+7Km7vHoyCMqYvKqyeB/greH8VgDGps8qlUAtmNykGSSqMblJP3+221rHAh2aX1UWHwDENZxbUDcGUIfnCiY2Z2f0i/NcB/OcKj4EwtR5AdSbCFhM3J86VGps3ux7mvSLsRUfAmHq/Kqy+LiDeQMwbzp464Smv4WqYMZAni2Wqz+SSunSK74vy1TpRwQ1JG7+FtAdmDwrwYF3UOOfpwBxpEqvASiqVal0pw9lmGom00L86xQhsmV6/aDSGFDsR3ecjPLeIZ08yMwyPnLOXTjnXuvSOTpeYrNlp+bm3Ge2D580RFXeHpW2MNmfxKJPLacNK9NyPg8CZEbZH3WKDOo8g8TK3DJs/2g5IRPmKUNMVOkFqI4H7/PuOOvubZkxKJ/SzKeaCh6DGXXB/jIkVCaqc8sr9JnKqyf1mQ/ULmgOPyeQQZ07w0lUJne4O57qIarz0q7DOXjxkBCkWi2408yDcb+ZW5ijt56ynwunExsW3VGmsxa7qrJ4a2ChjtJiZa7K4muCZ44rWaG4ksiWs/D1kIwhctTM5BLrM/F+q873xqjz8h4UPLYcVVl8E1mSUasOOzZLWCja3q/K4pPcQl5ePbnXriD2vh6Q34rbFhvJivvM2O6GlxP6qiw+dYl2ecD+NDP89h2F0/jcifil43PlqfkBXveo+ypwec9qjJUHyxQxjlHGlirU9Utes4ydENtl0aosPotV4Nisp3l/T6uUarmCI+2q1W6VyWoM9/g/tX1pVRafuxO3qix+gFkORtXVymVs6cLsM5WkESYuOJ26rY2Ei2wMtI41c+V0VP/BMNdVWXzhTtSqV807LE2EdC3WgWLq3AEaAh2NsUmJYYZJ/02Y/Fdl8aVz7rFz7nVKF4vl6it3QKvK4kcq+8aAd00gOQWwqqnfgclAQ5zOVKUx1ZrR/sxDWy3KjSDb9C+ch+tw7yZHnaxMF+kvbztQa15Dp6mXP6IpKINUMBEgQlQLargn6c7GLlYmnrM6rQ0JvXPWA1ofSIRoAVV9p9rVYW52ZXUGmEGdOHd1NJ/1RwQUuyeEidAY4nVCM0dVbnfHWcp0YrYTgK2NzVwefncsMC1lBnWmqhKdDwOVDkg5IqVOZzRrf6TKzOkrrxObuNxWyDB5iIR7uxGoDNu7/4/Jmxf2bAEAKgxVyWARJoK0mvcOUEuZfN1mFIzhuTE7QfZssWERq5QH7TgDUlu178yAUr62qMOOBShgMA996EwMmY55aBQbnIc+kgfqO3uL2GLe3FETR6DB2pc54eHnRwRTAbWgqmCH3KQl+s2oMi2g7OE5zWFV79CmAjS4oy0W6FCe2wTpEiqsgOIRHdKsS6Gg7XLpoU19XcHbrXnrtRUhioJ0ieqJKRSBbkShD20qtrDp+SBgEEiX0RT5YRwyxQIihzYVQlTljAV/ZexSWU6/poZMONGvRTq0WRD7wCmAUZBuwFiQR/388prUcGhjcOraAsmBjChIN8LjpkTnmyNYbFNKVGNG1aSxbkk2mwhkY8zlD23q+0hUowxYCIhJQIdO+VT/6UQzObRZ40YzwBupW6+NnT+zGhuYyycXYo+mlm55II5zbRURSrahYTIeqM+7FDaGXnQJF9gew/Fxtwk/JLXVOcymOLCCCgogcJjDAeA2/d2lf+AYUgh0WItmyWDHTvm4aTTUqauZR1vR8GECAtrQDt2dLxnEGpUzVk9vI7FJHqRbTgePyTbF/NkCWVMleQOpo9XQs+53Z8bSCBsPx3BWw4Fg/nxPjTMV0CwbMzTyPQP4jQgw4AIc9q+3xr7xFGWGPPAfh0Fgpc7oN5CirnuFiUDVsKimZo7LwwwlADjv2zNO77beh1EhDvqyd++bMjaHbuYNgVSbExBCAHmToEqXoU5s7oPWdHJtCgeE6qwhijQTq5kKdu/HShFvrhxeLBicuto4COhUAdzGUGaAESLyytMrkNbXxiEPfKcznB47JITLHt2a+WTZ2D6TrxsR5+TfhEorReZsZlD/QMv5cYqNJweDnXJpoaGK4X1LlZYi1eYvVibmX0cUagWGVfMeNWubygF5AyT/LlQU9ynFvHeKMmPenaNEsXjmUTkgD6AU0OBxLYhqi00w1V3gOavfgtr0xDHdGKBTbWHxBIABWeDUBrAhW2u4mVqB3lggWOWTDWEK83BkoAiL7/U1677yxRTKjon7Vr43uplPubnKw5HPlXe2mvXQMqkhk6U6NUgfBXJMwfvy8+JoKTCmxBxl8rUFSoEbDTKlsGPz9AagmArHKlPdU/0g3xsFcl8wnci/rwnn3g9mAei7P4kS2f4DIM+767BxJm4AAAAASUVORK5CYII="/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.9802"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="1" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{2391acfc-ac19-491d-ab73-bbfc10d66e8f}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="bank" filter="&quot;fclass&quot; IN ('bank')" key="{039cf19d-2623-4da8-8b70-d7bcd6e92c9e}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.847916666666666" shapeSizeY="10.583333333333334" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="0.97561"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFIAAABQCAYAAACK5CKQAAAIu0lEQVR4nOWcPYsrVRjHz0yydxO/hSEiBMTGwkLQ8oJN7AQrv4BfwNbeQkHwgt4rCBerFBZ2YmFnPdUwlSCoVxu9u3uzuyMJ84R/nv0/55x5yyTrA4eZycvMmV+et3PmPEnc8UjS8vulO+HOd3XNJPK1ELjY104WZEL2k476VAZeLw8BtU+QCbmGD2gdrfRpXggge7+1jF33khhb2U+MzyQtTbs0YIaAlccGMoGtD15KPss+j+fUYoGSY3z/1vhs0qXZdwUyMbQsJfsC0mrsnFp8AHWTc9zCd2Rfn78cCiTTwsSAlnq2+Fl9PrwOg6c1TyDprWggnkO+49oCbQNSw0sC0HZtNl/84TqQIs9e9gC8gWNsCNXnR8tDRG0WNFKyHVX7o9l88afrUYo8e0VBRHhyLHBvPJrLfG0vIK3gkQo00Ly/3QBS5NmrAE43BItwEWhtmHVBWgEihTaqNPCZG1CKPHsN4F2rLYOLps9aZyCZJuo2aqKFy6cPoz63ev+HJkBfrwBiE6gIVvvSWpqZdABxBBD/6hpeF1CLPHvDObeuwMlW9lFTtdlHw4wB6TPlUR1TXraE1wZqkWdvVuA27YWCuvaYe5SZJy01cXCINWG+VUEUmLKPUC3f6Xww64DEqBwNcdkzwLpAizx72zl3VYG7ApjSWEDCqE5Byqgi1qR3qc0xQoy55my++Mk5N3XOnTvnJtX2QdXOqkHK3n0GhrJekHrEIicVmONjhFgD5o8AU9oZtO09AkS8fzqhEtJI5wkyRwmxRh+mlUZOKm0UmGOAqQGas1JpjSiNfvH3Y4YY05fZfPG90kpm3tisWaso09azN94x8/KIINaAiVqpYaK/RA5B02bqq1Oe2h0eWgJ9mxhayQKPhrjj5ZtGo2Nod/9kQoaGmPqMPMl5Ix+5mc357dS0MdTH2XzxbQ2NjPKR1kSt16xPAWJEXy2IGHR8ETwZ/8/NGkFeG22sTDxlpq1BsmclEq1/dQPJSg37uraC2XzxZZFnH1ZDRNHINUmDbqxnSeOI0QxGq15vqM28Y6xs+myc/wGMtyUpl/1rwuMWnv3sTJtpofaTvcsqAmCPPhl941k1maF9pGZShoKNHOPEba+y6lELI0WCiy/QIFAXCjbWrE9vmrEiEPvMBgzzRog4aYEteohopT91nu0cNUSPIDgr7TEnMNi40UrIDyLL4fJSrX0apDchHxsQcd+M2n34xJXHV/YM2YJnwXS4r4MNijnTcU8lVYMPayTDXF0SmkazvngfJSXTZVoTTcVjeaTz+YK+Iudy+DG7hscYmEys2Z+Y1+5bHpka2Yqen0XZCzZ3XuxTE33gBgw0IjHaR1+Lica9Aj0i8bmyoGJZCfkpmGJj6bjvSV9VDVEiptr3FNmhJD2mMrQTlS2zGB9prsDqwkSWSgM35+zTbXjO7VtxFlzWh6aN5RJ3vrhZYzibL35xB5qNWR0wghd59mlEmYkIfY1pZOsV/k1kYN/IVpvhsXyGfW8rAtKnyl617tIMl08f9go0wqxj1pJTHjqTx0E7LuGYVu2l2Xzx89DPb5YNrmVBLPLsc+fchXPuX2j/VE32n1efuYAFqi9wQar2kSiNSyVOzOR1XY5v6bNT9Ti7c+w9wCE+Qav75gInl6Cv/H3DRfhsybNVPuJwn/lI5gt2Jyry7J2GHR5EfH0q8uwLo+6mTg2ONyFn0Wv3CxV59vAUYK78EB8Z9Te6sAkhMlM3E3JGXf9K101v4FAS0Qe2PAUX41uL8oMayRJPVre3vUiRZ++2vJEhKxseqeovXcRkVYVhMegeN8tHsuRUq/26yLP32tzQQBC/qu4B62x0eYiuCEOA2uV5l6pIPikPzSWfPMecUtpsvvjuRAqWHle1NZdVu6hyxOeQQ8ox5o5XpMBpr1SZBRvLvFEj5VfbtiLPPujiRg8AUVd9ISBWuMQqwWi6mESMcmQdjGilLF5nmvnkSIs6H0Oll2ikaBtqoNZE0VwBjXD3UiLrWTaatzbxcwPmtIK58UHHVGYsmijt0gB5YUDEMjvmM7db37OJvdoaWPZmwZwC0OlsvvjMDShFnn2jXBBqI4LUAC2IuoJ2L/j4JnbZ8BD9pO7gFXTgssizj9xAUuTZ18SMLz0N78Eq7tQjnD2xntUK4N2fe6j1g2eqjm8CJWminaKx2zqW2XzxSc/wnpAUDYPLnR9baeBFAKqcUwYoDqFaIH0mzlKiCQG6BxIqB85m88XHHWoe/rOKzixCIDVANGfmF1k+aYLUMPXKLNRKATqBreSaGjArUTsjCzlHEWuOcIoPtUQaJtY60CAwyRElMl966retyQsXehxbVjfCZoFuPA/Oy2p7Z1gJN1enlkXDtGamzDxXaaT26aKBV2RkY4G74yPHERAFioDDOck1vO7UhXSgkg76NFIvYnIGSOsaIY3UQDEpR/DoZ/E6JsyQRupj1MSbGppyTTQyBNIRrWSz1SGQFszQXzHoP1gyn9eEQGqRqqfbAPzSA1JDjK2LDv1gbJqPwVw3+HMQ9MemhEAi+SRw0tIzhykgGUQsnGwDEn80C2bTv6vR160NUsNkx46YW0gjpRiIQWwTbPT1tJn39gdKsaatNVNrZUnm6dDkpAxtbNT4pR2lP9ZMVe9/6VXHR1pmXhrtFgohpeOWT2RmzdZrYx/w2tZMfps/mYuGWBekvhE5TtWvJ1t9U6PqRrQWsgXvmPpYpo3XYakQA8rMF1Mc1PRoiE1AWmaewDFGeAQtMPVIKQn4Rl8eyXwlmrkGy5696G1tiE1B4s2g3ILJY3G4+D3JPQUYQtSL330L4PH6lm8WmAww+6wGVwti2xW7VvROyLFsERhCZZoYWrvJTJBpp/alaL5MC61780rbpc/WBW8MoM4IKHpftj6N1DeNUDQ8FwCoz1lbulpDXqpjK3lH7XRGYLGm9th15DUWgNh7LCg21kLWwS4lga31cI0d6++E+mZpkuXv2GfwPK3kP1JHKV+ogrpYAAAAAElFTkSuQmCC"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.8479"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="1" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{a365dc47-7cb6-4bba-bc52-69fe2804f103}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
      <rule description="sight" filter="&quot;fclass&quot; IN ('attraction', 'castle', 'museum', 'monument', 'viewpoint')" key="{d345e595-7e43-41a5-b411-ca4a570b63ad}">
        <settings calloutType="simple">
          <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="'█'" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="19.579166666666666" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="MM" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="1" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" tabStopDistance="6" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Percentage" textColor="255,255,255,255,rgb:1,1,1,1" textOpacity="0" textOrientation="horizontal" useSubstitutions="0">
            <families/>
            <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="0" bufferJoinStyle="128" bufferNoFill="1" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
            <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
            <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="1" shapeSizeUnit="MM" shapeSizeX="10.980208333333334" shapeSizeY="10.054166666666667" shapeType="5">
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="RasterMarker" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="alpha" type="QString" value="1"/>
                    <Option name="angle" type="QString" value="0"/>
                    <Option name="fixedAspectRatio" type="QString" value="0.915663"/>
                    <Option name="horizontal_anchor_point" type="QString" value="1"/>
                    <Option name="imageFile" type="QString" value="base64:iVBORw0KGgoAAAANSUhEUgAAAFMAAABMCAYAAAARMotOAAAGvUlEQVR4nO2czW7jNhDHqY90k/QReihgey/uqcfe+nIFir5Mn2aNAmsZ2FfoorvdxLGKGBxh9PfMiIopirY7ACGJlmXpl/kiw1Hh5pci8vVadyUPMvb3igj31Ab0tdcEs1C2se6nHejH7cXBLGBf0koLbnGGRraKdvK+9lJgFsYWIUpAQ+9LgtMK+5qGRgVau/hSDEDUmvZdTYbgSW3oWtnALNhWg1iyrWPHFlRNLIgH339gxxrU1v9Wm4OZj4VYCn18GwJUAnkwthrUqOZfp4C4WK3/cQlkt938wOBJrQjQVEnaKWBqEbqA4xJaKnnnnHsBgC9CnwTVMfdQjMhhR8MMic4FaCS1yqWTewAoNQkqNX6Mzz84EKgjQSx9f8WOqxlgPnhgewZvHwBVC2CaGyDwtD8IM8QnUqtAIytoPWk+fnAxZPn+J+x69PCoEcznQKAHAZQElmtwp7X1SJCY0kgQSwaxniiXHdLMZwbzyd8D79OASplAAfsS8OM50oNaWogpDgdYgjbWM8D83kO7Y9pYeYgVaOue+VcerFq2XwK8g+/jcDuglmYi1A7gYrX+7DKUxWr951u/u9tufgS4FYBG0y+xH2FKKU5nzqnyxTlksVp/2m03K3ABBJSag9FVD6iVA6JJp4zKs8hitd76XJXaHbgrcmE4knuVgsM088XFav23uwFZrNZ/eZDfscah4oCks+Qhn8mBqhIr1Rkr5/yukFZh8k8p1dAcAX3e85maZoq54rkPM7e83rsB9MGnVBhDnDFR0pk5jrmdkJRfnTS6Mtz79k4xdfKbPVaS+WojmdAbuShRnoNA3jOQd0IQ4lB7eaY2bEwayZeK6SX+471CJEXj43XKOyltorToBCYJDh8nn0Zb2sHg5JwEYF99poNhpZR/EpuD5DMR5OSauQwAGeM7I4XyTPSV6C97s2bciTplQmMyzVyeAWVioAiTmuYvzaRdGgFFlWUEGBMCRYg88FDDyR8Vkjb5G0WWESFMBBRBSkNJrmS91EjL8KWk9RakVrQRfaXjx1qeOWo4GVOTmo8fuhbrmm8QKeDg/O2JomGeifu4nUwaAR71JYjeKDjhLZo1aihqnDWsnC0hbwK0NDJwnBESp9xQ2TQz5/u35i+lAYs0MjwRyxdKWnorUhrDa35MMjjT3jvxxqRQmnbeUUKj9KRAlwP+boYApIkJN+W/YYOA8WAzM8QQzcwTZoZaOFpSrlBzU06d5TBZnRTmtUtymM0EGpSDVr7K/5p56TCbiJqUi1bOqplNBAg5gZzdzJszYOQGMguf2bwBSo4gs0nam4BRzwwAx1S4BcMMrZWJIrlqnRcTbpljEXwGElp72euXYA6VFl/8GDrgObDYSlr1xpm0IQHIrCW8dKBL/f55zSWBpX7V7SFMibxp7pcKdGnfNxZbYVmLyKg2SoWDI9mlAjUEy1m4lqoLXvmyOS4n5ce77eZndwOy225+E6rcsLBVrAoux0Sz3Xbzi7ti2W03v/t17FY1mxaMOs2kTssJH/8qu+3mV3eFsttu/vDr2Akkh8rBIhNHMK2CgBrKNx78itpHv//g9x99/wNbtkxtaJ1OSsGqXa5xT6z965z76rdffPvq2xf2OZ3faXENRZXaj/Iff2brcJ6gGNXB9y4FJmnhN2gEixrXTm72x+vXQiSXGn2ZO+ZnAVLrz6VzEKS0uDY1UGlpNcF6UmBKAQn5mGPzVqgflCCiRu6VygRpmUkqwYCBr5zgPpKD/CaZs1b8j3km/2EqtORlxuRTecGRg5u7A5jaCrLUwoFiqsNhEjwEyrWTl1N3Dc3cCYXqvPaagHIgdLEXRSvRp+YCk+5Z0k5u8txvomb2TD5kBERfkoIHgtyzAIVaebIELxFUHBbjEBHjAQLlW8lvdtdEn8mB8oIhDpOfK8GsFF8prSRLJdoQGX0nfyUFgSUTH+UzESaZufbQHGTN3oNhlRHPAZLfL79vaVCCr53QmjgassycV/o7/9menSuZSaWkQpKLmEMzaR+BSrknh8qPpReknMB0Ss55EG4KTbxSFtBr6VAOmukUmDihEfL6nuO1rAWc9BmCsaoPKjjXKidMLVIgcsLrd/ANMmiB+Aega4kwLaB8rTcCLhSznhPg2ICkQeVuDS2203QLJm0LpaaSwy2ECRO8jvV7OWmoBJbDk/6Ncdy3Hk4DKmmsM7QxB4CaoP/sRWdFAzXfO/igGH2LEaBJ5orgoZEdPzOBQV/vGqEPZ5lriCkXLj9pjT7cDn32poe0IKKM7Z8LYEi/pc1RHswyZxfh+qnE0lDrnBP5D/Il4pAxoousAAAAAElFTkSuQmCC"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="scale_method" type="QString" value="diameter"/>
                    <Option name="size" type="QString" value="10.9802"/>
                    <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="size_unit" type="QString" value="MM"/>
                    <Option name="vertical_anchor_point" type="QString" value="1"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
                <data_defined_properties>
                  <Option type="Map">
                    <Option name="name" type="QString" value=""/>
                    <Option name="properties"/>
                    <Option name="type" type="QString" value="collection"/>
                  </Option>
                </data_defined_properties>
                <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
                  <Option type="Map">
                    <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                    <Option name="joinstyle" type="QString" value="bevel"/>
                    <Option name="offset" type="QString" value="0,0"/>
                    <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                    <Option name="offset_unit" type="QString" value="MM"/>
                    <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                    <Option name="outline_style" type="QString" value="no"/>
                    <Option name="outline_width" type="QString" value="0"/>
                    <Option name="outline_width_unit" type="QString" value="MM"/>
                    <Option name="style" type="QString" value="solid"/>
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" type="QString" value=""/>
                      <Option name="properties"/>
                      <Option name="type" type="QString" value="collection"/>
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0.69999999999999996" shadowRadius="1.5" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </dd_properties>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="3" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
          <placement allowDegraded="0" centroidInside="0" centroidWhole="1" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="UnknownGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="FollowPlacement" lineAnchorType="0" maxCurvedCharAngleIn="25" maxCurvedCharAngleOut="-25" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MM" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="1" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="1" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
          <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="0" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="1" scaleMax="0" scaleMin="0" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
          <dd_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
              <Option name="blendMode" type="int" value="0"/>
              <Option name="ddProperties" type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
              <Option name="drawToAllParts" type="bool" value="false"/>
              <Option name="enabled" type="QString" value="0"/>
              <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
              <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{4277bf6b-2925-49f5-aa2a-8390c4aa0699}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
              <Option name="minLength" type="double" value="0"/>
              <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="minLengthUnit" type="QString" value="MM"/>
              <Option name="offsetFromAnchor" type="double" value="0"/>
              <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
              <Option name="offsetFromLabel" type="double" value="0"/>
              <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
            </Option>
          </callout>
        </settings>
      </rule>
    </rules>
  </labeling>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks type="StringList">
      <Option type="QString" value=""/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <fieldConfiguration>
    <field configurationFlags="0" name="fid">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="osm_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="code">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="fclass">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" index="0" name=""/>
    <alias field="osm_id" index="1" name=""/>
    <alias field="code" index="2" name=""/>
    <alias field="fclass" index="3" name=""/>
    <alias field="name" index="4" name=""/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" expression="" field="fid"/>
    <default applyOnUpdate="0" expression="" field="osm_id"/>
    <default applyOnUpdate="0" expression="" field="code"/>
    <default applyOnUpdate="0" expression="" field="fclass"/>
    <default applyOnUpdate="0" expression="" field="name"/>
  </defaults>
  <constraints>
    <constraint constraints="3" exp_strength="0" field="fid" notnull_strength="1" unique_strength="1"/>
    <constraint constraints="0" exp_strength="0" field="osm_id" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="code" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="fclass" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="name" notnull_strength="0" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="fid"/>
    <constraint desc="" exp="" field="osm_id"/>
    <constraint desc="" exp="" field="code"/>
    <constraint desc="" exp="" field="fclass"/>
    <constraint desc="" exp="" field="name"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValuePolicy/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression></previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
